
<template>
    <div class="purchase-international">
        <van-sticky>
            <div class="header fs_32 c_333">
                <i class="iconfont icon-back fw_600" @click="$router.back()"></i>
                <p>采购订单（国际贸易）</p>
                <p @click="$router.replace('/PurchaseOrder/domesticOrders')">切换</p>
            </div>
            <div class="date">
                <span class="orders">所有订单</span>
            </div>
            <div class="total">
                <div>
                    <p>订单金额</p>
                    <p><span class="fs_28 fw_600">1884.07</span>美元</p>
                </div>
                <div>
                    <p>订单数</p>
                    <p><span class="fs_28 fw_600">520</span>单</p>
                </div>
                <div class="noborder">
                    <p>待提货值</p>
                    <p><span class="fs_28 fw_600">18.07</span>美元</p>
                </div>
            </div>
        </van-sticky>
        <div class="order-list">
            <van-tabs v-model="active" :ellipsis="false" sticky offset-top="151" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="全部">
                    <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        @load="onLoad"
                    >
                        <div class="list-item" v-for="item in list" :key="item">
                            <div class="item-title">
                                <p class="c_666">订单编号：201908152412</p>
                                <p class="price fw_600">$88,92</p>
                            </div>
                            <div class="item-content">
                                <div class="item-l">
                                    <p class="fs_26 ellipsis">原膳澳洲和牛西冷牛排(M4-5)150g</p>
                                    <p class="fs_26 ellipsis">原膳澳洲和牛西冷牛排(M4-5)150g</p>
                                </div>
                                <div class="item-r">
                                    <p class="p2">共2件</p>
                                </div>
                            </div>
                        </div>
                    </van-list>
                </van-tab>
                <van-tab title="待付款">内容 2</van-tab>
                <van-tab title="待发货">内容 3</van-tab>
                <van-tab title="待报关清关">内容 4</van-tab>
                <van-tab title="待入库">内容 5</van-tab>
                <van-tab title="已完成">内容 6</van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {

    },
    methods: {
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.purchase-international {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #fff;
        padding: 0 30px;
        border-bottom: 1px solid #F4F4F4;
        height: 88px;
        i {
            font-size: 40px;
        }
    }
    .date {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        height: 80px;
        background-color: #7FC7FC;
        padding: 40px;
        .orders {
            color: #343434;
        }
    }
    .total {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        height: 134px;
        color: #fff;
        background:linear-gradient(180deg,rgba(127,199,252,1),rgba(47,138,230,1),rgba(12,105,212,1));
        padding: 0 20px;
        div {
            flex: 1;
            border-right: 1px solid #fff;
            margin-left: 20px;
        }
        .noborder {
            border: none;
        }
    }
    .order-list {
        background-color: #F4F4F4;
        .list-item {
            background-color: #fff;
            margin: 10px;
            .item-title {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 64px;
                border-bottom: 1px solid #F4F4F4;
                padding: 0 20px;
                .price {
                    color: #FF0000;
                }
            }
            .item-content {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 132px;
                padding: 0 20px;
                .item-l {
                    width: 450px;
                    p {
                        margin: 10px 0;
                        color: #343434;
                    }
                }
                .item-r {
                    p {
                        margin: 10px 0;
                        color: #9A9A9A;
                    }
                }
            }
        }
    }
}
</style>