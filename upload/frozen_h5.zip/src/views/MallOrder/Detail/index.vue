<template>
    <div class="international-order-detail">
        <CCII-Header>查看订单详情</CCII-Header>
        <div class="detail-content">
            <div class="detail-describe tc">
                <p class="p1 fs_26 fw_600">待付款</p>
                <p class="p2">需付款：<span class="fs_32 fw_600">￥5500.00</span></p>
                <p>请到中冷官方网站电脑端进行支付！</p>
            </div>
            <div class="address" @click="$router.push('/mallOrder/detail/receivingAddress')">
                <i class="iconfont icon-dizhi"></i>
                <div class="fs_26">
                    <p>王小维   15501078677</p>
                    <p>北京市朝阳区呼家楼街道三里屯大厦</p>
                </div>
                <i class="iconfont icon-youjiantou"></i>
            </div>
            <div class="detail-content-box1 categories-one clearfix">
                <div class="cate-title">
                    <p class="c_666">武汉鲜美达店铺</p>
                </div>
                <div class="cate-detail">
                    <img :src="require('assets/gqdt.png')" alt="">
                    <div class="cate-name">
                        <p class="fs_26 p1"><span class="product-name ellipsis">阿根廷进口京精品牛一把</span></p>
                        <p class="c_666 p2"><span class="tip ellipsis">发货地：天津</span></p>
                        <p class="c_666 p3 ellipsis"><span class="ellipsis">数量：100</span><span class="product-price fr tr fs_28">￥5500.00</span></p>
                    </div>
                </div>
                <div class="cate-total tr">
                    <p>合计：<span class="fs_28 fw_600">￥5500.00</span></p>
                </div>
            </div>
            <div class="detail-content-box2">
                <div class="order fs_26">
                    <p class="c_666 sn">订单编号：<span>20190806123456</span></p>
                    <p class="c_666">下单时间：<span>2018-08-06 18:00</span></p>
                </div>
                <!-- <div class="paymethod">
                    <p class="c_666 fs_26">支付方式：<span>中国银行</span></p>
                </div>
                <div class="total-price">
                    <span class="fs_26">商品总额</span><span class="fs_28">￥5500.00</span>
                </div> -->
            </div>
            <div class="cancel-order">
                <div class="confirm"><p class="fs_32">确认收货</p></div>
                <div class="cancel"><p class="fs_28">取消订单</p></div>
            </div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.international-order-detail {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .detail-content {
        width: 100%;
        height: 218px;
        background: url('../../../assets/gjmydd-bg.png') no-repeat;
        background-size: contain;
        .detail-describe {
            height: 100%;
            padding: 32px 0 53px;
            color: #fff;
            .p1 {
                margin-bottom: 30px;
            }
            .p2 {
                margin-bottom: 16px;
            }
        }
        .address {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            height: 132px;
            background-color: #fff;
            margin: -10px 10px 10px;
            padding: 10px;
            div.fs_26 {
                flex: 1;
                color: #343434;
                line-height: 1.5;
            }
            i {
                font-size: 40px;
            }
            .icon-dizhi {
                margin-right: 10px;
                color: #00428E;
            }
        }
        .detail-content-box1 {
            margin: 10px 10px 0;
            background-color: #fff;
            .cate-title {
                padding: 0 20px;
                height: 64px;
                line-height: 64px;
                border-bottom: 1px solid #F2F2F2;
            }
            .cate-detail {
                height: 132px;
                padding: 0 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid #F2F2F2;
                img {
                    width: 120px;
                    height: 110px;
                    margin-right: 10px;
                }
                .cate-name {
                    flex: 1;
                    line-height: 1.1;
                    .p1 {
                        .product-name {
                            display: inline-block;
                            width: 550px;
                            color: #343434;
                        }
                    }
                    .p2 {
                        .tip {
                            display: inline-block;
                            width: 550px;
                        }
                    }
                    .p3 {
                        span:nth-child(1) {
                            display: inline-block;
                            width: 400px;
                        }
                        .product-price {
                            color: #FF0000;
                        }
                    }
                }
            }
            .cate-total {
                padding: 0 20px;
                height: 64px;
                line-height: 64px;
                p {
                    color: #343434;
                    span {
                        color: #FF0000;
                    }
                }
            }
        }
        .detail-content-box2 {
            margin:0 10px;
            background-color: #fff;
            border-top: 1px solid #F2F2F2;
            .order {
                height: 132px;
                line-height: 1.5;
                padding: 30px 20px;
                border-bottom: 1px solid #F2F2F2;
                p {
                    span {
                        color: #343434;
                    }
                }
            }
            // .paymethod {
            //     height: 80px;
            //     line-height: 80px;
            //     padding: 0 20px;
            //     border-bottom: 1px solid #F2F2F2;
            //     p {
            //         span {
            //             color: #343434;
            //         }
            //     }
            // }
            // .total-price {
            //     display: flex;
            //     justify-content: space-between;
            //     align-items: center;
            //     height: 80px;
            //     padding: 0 20px;
            //     .fs_26 {
            //         color: #343434;
            //     }
            //     .fs_28 {
            //         color: #FF0000;
            //     }
            // }
        }
        .cancel-order {
            position: fixed;
            bottom: 0;
            left: 0;
            text-align: center;
            background-color: #fff;
            width:100%;
            height:95px;
            line-height: 95px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .confirm {
                height: 100%;
                width: 558px;
                background:linear-gradient(13deg,rgba(34,143,237,1),rgba(3,90,190,1));
                color: #fff;
            }
            .cancel {
                flex: 1;
                color:#EA5620;
            }
        }
    }
}
</style>