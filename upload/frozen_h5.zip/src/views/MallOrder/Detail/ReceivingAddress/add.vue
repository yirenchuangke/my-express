<template>
    <div class="address-container">
        <CCII-Header>{{$route.query.id ? '修改地址' : '新增地址'}}</CCII-Header>
        <div class="address-form">
            <van-form @submit="onSubmit">
                <van-field
                    v-model="name"
                    name="姓名"
                    label="联系人"
                    placeholder="姓名"
                    :rules="[{ required: true, message: '姓名' }]"
                />
                <van-field
                    v-model="tel"
                    type="tel"
                    name="手机号"
                    label="电话"
                    placeholder="手机号"
                    :rules="[{ required: true, message: '手机号' }]"
                />
                <van-field
                    readonly
                    clickable
                    name="省市区"
                    :value="value"
                    label="省市区"
                    placeholder="选择收货地址"
                    @click="showArea = true"
                />
                <van-field
                    v-model="area"
                    type="text"
                    name="详细地址"
                    label="详细地址"
                    placeholder="街道，小区，楼牌号等"
                    :rules="[{ required: true, message: '街道，小区，楼牌号等' }]"
                />
                <van-popup v-model="showArea" position="bottom">
                    <van-area
                        :area-list="areaList"
                        @confirm="onConfirm"
                        @cancel="showArea = false"
                    />
                </van-popup>
                <!-- <div class="save">
                    <van-button native-type="submit">
                        保存并使用
                    </van-button>
                </div> -->
            </van-form>
        </div>

        <div class="save" @click="save">
            <p class="fs_28">保存并使用</p>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            name: '',
            tel: '',
            value: '',
            area: '',
            showArea: false,
            areaList: {
                province_list: {
                    110000: '北京市',
                    120000: '天津市'
                },
                city_list: {
                    110100: '北京市',
                    110200: '县',
                    120100: '天津市',
                    120200: '县'
                },
                county_list: {
                    110101: '东城区',
                    110102: '西城区',
                    110105: '朝阳区',
                    110106: '丰台区',
                    120101: '和平区',
                    120102: '河东区',
                    120103: '河西区',
                    120104: '南开区',
                    120105: '河北区',
                    // ....
                }
            }, // 数据格式见 Area 组件文档
        }
    },
    methods: {
        onSubmit(values) {
            console.log('submit', values);
        },
        onConfirm(values) {
            this.value = values.map((item) => item.name).join('/');
            this.showArea = false;
            console.log(this.value)
        },
        save() {
            console.log(this.name,this.tel,this.value,this.area)
        }
    },
}
</script>

<style lang="scss" scoped>
.address-container {
    height: 100%;
    width: 100%;
    background-color: #F2F1F1;
    .address-form {
        // height: 100%;
        background-color: #FFFFFF;
        margin: 10px 0 98px;
        .van-cell {
            height: 110px;
            line-height: 110px;
        }
    }
    .save {
        position: fixed;
        bottom: 0;
        left: 0;
        width:100%;
        height:98px;
        line-height: 98px;
        text-align: center;
        color: #FFFFFF;
        background:linear-gradient(13deg,rgba(33,142,237,1),rgba(3,90,190,1));
    }
}

            
</style>
<style>
.van-field__label {
    width: 120px;
}
</style>