<template>
    <div class="address-container">
        <CCII-Header>收货地址</CCII-Header>
        <div class="address-item">
            <!-- <van-address-list
                v-model="chosenAddressId"
                :list="list"
                :disabled-list="disabledList"
                disabled-text="以下地址超出配送范围"
                default-tag-text="默认"
                @add="onAdd"
                @edit="onEdit"
            /> -->
            <div class="address-detail">
                <div class="address-text" @click="chooseAddress">
                    <van-radio checked-color="#5A9EE2" icon-size="16px" name="0" v-model="chooseId" shape="square"></van-radio>
                    <div class="fs_26 c_333">
                        <p>王小维   15501078677</p>
                        <p>北京市朝阳区呼家楼街道三里屯大厦</p>
                    </div>
                </div>
                <i class="iconfont icon-bianxie c_999" @click="editAddress('传id')"></i>
            </div>
            <div class="address-detail">
                sfd
            </div>
        </div>
        <div class="add-address" @click="editAddress()">
            <p class="fs_26">新增收货地址</p>
        </div>
        <!-- <div class="confirm">
            <p class="fs_28">确  认</p>
        </div> -->
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            chooseId: 0,
            // chosenAddressId: '1',
            // list: [
            //     {
            //         id: '1',
            //         name: '张三',
            //         tel: '13000000000',
            //         address: '浙江省杭州市西湖区文三路 138 号东方通信大厦 7 楼 501 室',
            //         isDefault: true,
            //     },
            //     {
            //         id: '2',
            //         name: '李四',
            //         tel: '1310000000',
            //         address: '浙江省杭州市拱墅区莫干山路 50 号',
            //     },
            // ],
            // disabledList: [
            //     {
            //         id: '3',
            //         name: '王五',
            //         tel: '1320000000',
            //         address: '浙江省杭州市滨江区江南大道 15 号',
            //     },
            // ],
        }
    },
    mounted() {

    },
    methods: {
        chooseAddress() {
            console.log(this.chooseId);
            
        },
        // 新增or编辑地址
        editAddress(id) {
            this.$router.push({path:'/mallOrder/detail/receivingAddress/add',query:{id}})
        }
        // onAdd() {
        //     Toast('新增地址');
        // },
        // onEdit(item, index) {
        //     Toast('编辑地址:' + index);
        // },
    }
}
</script>

<style lang="scss" scoped>
.address-container {
    height: 100%;
    width: 100%;
    background-color: #F2F2F2;
    .address-item {
        background-color: #F2F2F2;
        padding: 10px 10px 98px;
        .address-detail {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            border-bottom: 1px solid #F2F2F2;
            height: 132px;
            padding: 0 20px;
            .address-text {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                width: 600px;
                .fs_26.c_333 {
                    margin-left: 20px;
                    line-height: 1.5;
                }
            }
            i {
                font-size: 36px;
            }
        }
    }
    .add-address {
        margin: 0 auto;
        height: 68px;
        line-height: 68px;
        width: 658px;
        border: 1px solid #00428E;
        text-align: center;
        p {
            color: #00428E;
        }
    }
    .confirm {
        position: fixed;
        bottom: 0;
        left: 0;
        width:100%;
        height:98px;
        line-height: 98px;
        background:linear-gradient(13deg,rgba(34,143,237,1),rgba(3,90,190,1));
        color: #fff;
        p {
            text-align: center;
        }
    }
}
</style>