<template>
    <div class="mallorder">
        <CCII-Header>国内商城订单</CCII-Header>
        <!-- <div class="switch">
            <div>
                <span :class="index===0?'bg':''" ref="cgdd" @click="handleSwitch(0)">采购订单</span>
                <span :class="index===1?'bg':''" ref="xsdd" @click="handleSwitch(1)">销售订单</span>
            </div>
        </div> -->
        <div class="mallorder-tabs">
            <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="全部">
                    <!-- <div class="tab-content"> -->
                        <van-list
                            v-model="loading"
                            :finished="finished"
                            finished-text="没有更多了"
                            @load="onLoad"
                        >
                            <div class="" v-for="item in list" :key="item">
                                <div class="categories-one clearfix" @click="$router.push('/mallOrder/detail')">
                                    <div class="cate-title">
                                        <p class="c_666">订单编号：201908152412</p>
                                    </div>
                                    <div class="cate-detail">
                                        <img :src="require('assets/gqdt.png')" alt="">
                                        <div class="cate-name fs_26">
                                            <p class="ellipsis">阿根廷进口京精品牛一把</p>
                                            <p class="fs_24">1000吨</p>
                                            <p class="fs_24 c_666 ellipsis">发货地：天津</p>
                                        </div>
                                        <div class="cate-price">
                                            <p>￥1000</p>
                                        </div>
                                    </div>
                                    <div class="cate-total">
                                        <p class="fw_600 tr">合计：¥1000</p>
                                    </div>
                                </div>
                            </div>
                        </van-list>
                    <!-- </div> -->
                </van-tab>
                <van-tab title="待付款">内容 2</van-tab>
                <van-tab title="待发货">内容 3</van-tab>
                <van-tab title="待收货">内容 4</van-tab>
                <van-tab title="已完成">内容 5</van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            // index: 0,
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {
        this.active = this.$route.query.index || 0
    },
    methods: {
        // handleSwitch(v) {
        //     this.index = v
        // },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.mallorder {
    width: 100%;
    height: 100%;
    background-color: #F4F4F4;
    // .switch {
    //     display: flex;
    //     justify-content: center;
    //     align-items: center;
    //     height:80px;
    //     background-color: #fff;
    //     border-top: 1px solid #F4F4F4;
    //     border-bottom: 1px solid #F4F4F4;
    //     text-align: center;
    //     div {
    //         span {
    //             display: inline-block;
    //             font-size: 26px;
    //             color: #666666;
    //             width:186px;
    //             height:54px;
    //             line-height: 54px;
    //             border: 1px solid #EEEEEE;
    //         }
    //         span.bg {
    //             background-color: #EEEEEE;
    //         }
    //         span:active {
    //             background-color: #EEEEEE;
    //         }
    //     }
    // }
    .mallorder-tabs {
        background-color: #F4F4F4;
        .categories-one {
            background-color: #fff;
            margin: 15px;
            .cate-title {
                height: 64px;
                line-height: 64px;
                padding: 0 20px;
                border-bottom: 1px solid #EEEEEE;
            }
            .cate-detail {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 132px;
                padding: 0 20px;
                border-bottom: 1px solid #EEEEEE;
                line-height: 1.5;
                img {
                    height: 110px;
                    width: 120px;
                }
                .cate-name {
                    width: 450px;
                }
                .cate-price {
                    p {
                        color: #FF0000;
                    }
                }
            }
            .cate-total {
                height: 64px;
                line-height: 64px;
                padding: 0 20px;
                p {
                    color: #FF0000;
                }
            }
        }
    }
}
</style>