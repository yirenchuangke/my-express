<template>
    <div class="shop-qa">
        <div class="qa-box">
            <img :src="require('assets/gqdt.png')" alt="">
            <div class="l fs_26 c_333">
                <p class="ellipsis">阿根廷进口京精品牛一把</p>
                <p class="ellipsis">厂号：bl55205</p>
            </div>
            <div class="r">
                <p class="c_333">1000吨</p>
                <p class="answer-num">3个问答</p>
            </div>
        </div>
        <div class="qa-list" v-for="item in 3" :key="item">
            <div class="ask">
                <img class="fl" :src="require('assets/wen.png')" alt="">
                <p class="fl c_666 ellipsis">澳洲进口牛肉，在世界排行第几？</p>
            </div>
            <div class="answer">
                <img class="fl" :src="require('assets/da.png')" alt="">
                <p class="fl c_666 ellipsis">在国内得进口比例占华中市场得15%的比例。</p>
            </div>
            <div class="more">
                <p class="fs_20 c_666">2019-09-09</p>
                <p class="fs_20 see">查看5条回答<i class="iconfont icon-youjiantou"></i></p>
            </div>
        </div>
        <div class="toask" @click="$router.push('/detailsOfDomesticGoods/askAQuestion')">
            <div>提问</div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'Qa',
    props: {

    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.shop-qa {
    position: relative;
    height: 100%;
    margin: 10px;
    .qa-box {
        height: 132px;
        background-color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 22px;
        line-height: 1.5;
        margin-bottom: 10px;
        img {
            height: 110px;
            width: 120px;
            margin-right: 20px;
        }
        .l {
            flex: 1;
            width: 460px;
        }
        .r {
            .answer-num {
                color: #EA5520;
            }
        }
    }
    .qa-list {
        background-color: #fff;
        margin-bottom: 10px;
        .ask, .answer {
            height: 62px;
            line-height: 62px;
            padding: 0 20px;
            img {
                height: 26px;
                margin: 20px 20px 0 0;
            }
            p {
                width: 620px;
                border-bottom: 1px solid #EEEEEE;
            }
        }
        .more {
            padding: 0 20px;
            width: 730px;
            height: 70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .see {
                color: #00428E;
                .icon-youjiantou:before {
                    font-weight: 600;
                }
            }
        }
    }
    .toask {
        position: absolute;
        right: 0px;
        top: 100px;
        height: 88px;
        width: 88px;
        z-index: 99999;
        background-color: #fff;
        box-shadow:0px 4px 8px 0px rgba(0, 0, 0, 0.05);
        border-radius:50%;
        padding: 8.5px;
        div {
            width:69px;
            height:69px;
            line-height: 69px;
            background-color: #fff;
            border: 2px solid #EA5520;
            border-radius: 50%;
            color: #EA5520;
            text-align: center;
        }
    }
}
</style>