<template>
    <div class="shop-detail" v-html="content"></div>
</template>

<script>
export default {
    name: 'Detail',
    props: {
        content: {
            type: String,
            default: ''
        }
    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.shop-detail {
    padding: 10px;
    background-color: #fff;
}
</style>