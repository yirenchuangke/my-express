<template>
    <div class="shop-evaluate">
        <div class="title">
            <p class="c_666">评论<span class="fs_20 count">100条</span></p><p class="fs_20 count">好评100%</p>
        </div>
        <div class="content" v-for="item in 2" :key="item">
            <div class="content-header">
                <img :src="require('assets/gqdt.png')" alt="">
                <p class="company ellipsis fs_26 c_333">王小维冻品公司</p>
                <p class="c_999">2019-09-09</p>
            </div>
            <div class="content-text">
                <p>太好了，开心，以后有牛肉了！！！</p>
                <div>
                    <img :src="require('assets/gqdt.png')" alt="">
                    <img :src="require('assets/gqdt.png')" alt="">
                    <img :src="require('assets/gqdt.png')" alt="">
                    <img :src="require('assets/gqdt.png')" alt="">
                </div>
            </div>
        </div>
        <!-- <div class="c_666 tc no-evaluate">
            暂无评价
        </div> -->
    </div>
</template>

<script>
export default {
    name: 'Evaluate',
    props: {

    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.shop-evaluate {
    margin: 10px;
    background-color: #fff;
    .title {
        height: 64px;
        border-bottom: 1px solid #F2F1F1;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 20px;
        .count {
            color: #EA5520;
        }
    }
    .content {
        padding: 20px;
        border-bottom: 1px solid #F2F1F1;
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            img {
                width: 50px;
                height: 50px;
                margin-right: 20px;
            }
            .company {
                flex: 1;
            }
        }
        .content-text {
            padding: 0 0 0 60px;
            p {
                margin-bottom: 10px;
            }
            img {
                width: 120px;
                height: 120px;
                margin-right: 10px;
            }
        }
    }
    .no-evaluate {
        height: 80px;
        line-height: 80px;
    }
}
</style>