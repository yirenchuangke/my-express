<template>
    <div class="ask-container">
        <div class="header">
            <i class="iconfont icon-zuojiantou" @click="$router.back()"></i>
            <p class="fs_32 c_333">提问</p>
            <p class="btn fw_600">发布</p>
        </div>
        <div class="qa-box">
            <img :src="require('assets/gqdt.png')" alt="">
            <div class="l fs_26 c_333">
                <p class="ellipsis">阿根廷进口京精品牛一把</p>
                <p class="ellipsis">厂号：bl55205</p>
            </div>
            <div class="r">
                <p class="c_333">1000吨</p>
                <p class="answer-num">3个问答</p>
            </div>
        </div>
        <div class="textarea-box">
            <textarea name="" id="" cols="10" rows="3" placeholder="说出您的问题，已购买的人会为您解答哦~"></textarea>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {

        }
    },
    mounted() {

    },
    methods: {

    }
}
</script>

<style lang="scss" scoped>
.ask-container {
    height: 100%;
    width: 100%;
    background-color: #F2F1F1;
    .header {
        height: 88px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #fff;
        padding: 0 20px;
        border-bottom: 1px solid #F2F1F1;
        .icon-zuojiantou:before {
            font-size: 40px;
            font-weight: 600;
        }
        .btn {
            color: #00418D;
        }
    }
    .qa-box {
        height: 132px;
        background-color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        line-height: 1.5;
        margin-bottom: 10px;
        margin: 10px 10px 0;
        border-bottom: 1px solid #F2F1F1;
        img {
            height: 110px;
            width: 120px;
            margin-right: 20px;
        }
        .l {
            flex: 1;
            width: 460px;
        }
        .r {
            .answer-num {
                color: #EA5520;
            }
        }
    }
    .textarea-box {
        height: 196px;
        width: 730px;
        margin: 0 auto;
        textarea {
            padding: 20px;
            height: 100%;
            width: 100%;
        }
    }
}
</style>