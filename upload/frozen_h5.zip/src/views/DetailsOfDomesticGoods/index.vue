<template>
    <div class="detailsOfDomesticGoods">
        <CCII-Header>商品详情</CCII-Header>
        <div :class="active==0?'content-box pb120':'content-box'">
            <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="商品">
                    <div class="product-img">
                        <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
                            <van-swipe-item><img src="./meat.png" alt=""></van-swipe-item>
                            <van-swipe-item><img src="./meat.png" alt=""></van-swipe-item>
                        </van-swipe>
                        <div class="product-describe">
                            <div class="clearfix"><p class="c_333 fs_26 fl ellipsis name">阿根廷进口牛腩 500g</p><p class="fr c_666"><i class="iconfont icon-shoucang"></i> 收藏</p></div>
                            <p><span class="fs_28 fw_600 price">$88.66</span>      <span class="fs_20 c_999 del">$1000.00</span></p>
                            <p class="c_666">规格：无骨   起批量：10kg</p>
                            <div class="clearfix"><p class="c_666 fl ellipsis name">发货地址：天津市天津中渔冷库</p><p class="fr status">现货</p></div>
                        </div>
                    </div>
                    <div class="commodity-evaluation">
                        <div class="title">
                            <p class="c_666">评论<span class="fs_20 count">100条</span></p><p class="fs_20 count">好评100%</p>
                        </div>
                        <div class="content" v-for="item in 2" :key="item">
                            <div class="content-header">
                                <img :src="require('assets/gqdt.png')" alt="">
                                <p class="company ellipsis fs_26 c_333">王小维冻品公司</p>
                                <p class="c_999">2019-09-09</p>
                            </div>
                            <div class="content-text">
                                <p>太好了，开心，以后有牛肉了！！！</p>
                                <div>
                                    <img src="./meat.png" alt="">
                                    <img src="./meat.png" alt="">
                                    <img src="./meat.png" alt="">
                                    <img src="./meat.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="more-evaluation">
                            <p class="fs_20" @click="active=2">点击查看更多</p>
                        </div>
                        <!-- <div class="c_666 tc no-evaluate">
                            暂无评价
                        </div> -->
                    </div>
                    <div class="qa">
                        <div class="qa-title c_666">
                            <p>问答</p><i class="iconfont icon-jiantou" @click="active=3"></i>
                        </div>
                        <div class="qa-item c_666">
                            <p><img :src="require('assets/hot.png')" alt=""><span class="ellipsis">澳洲进口牛肉，在世界排行第几？</span></p><p class="fs_20 num">33个回答</p>
                        </div>
                        <div class="qa-item c_666">
                            <p><img :src="require('assets/wenhao.png')" alt=""><span class="ellipsis">牛肉咋样？新鲜吗？吃着怎么样？</span></p><p class="fs_20 num">33个回答</p>
                        </div>
                        <div class="more-qa">
                            <p class="fs_20" @click="active=3">查看更多问题</p>
                        </div>
                    </div>
                    <div class="graphic-details c_666">
                        <p><img :src="require('assets/shangla.png')" alt=""><span>上拉查看图文详情</span></p>
                    </div>
                </van-tab>
                <van-tab title="详情">
                    <Shop-Detail :content='content'></Shop-Detail>
                </van-tab>
                <van-tab title="评价">
                    <Shop-Evaluate :evaluateList='evaluateList'></Shop-Evaluate>
                </van-tab>
                <van-tab title="问答">
                    <Shop-Qa></Shop-Qa>
                </van-tab>
            </van-tabs>
            <div class="footer-operation" v-if="active==0">
                <div class="dianpu c_666" @click="$router.back()">
                    <img :src="require('assets/shop-icon.png')" alt="">
                    <p>店铺</p>
                </div>
                <div class="caigoudan c_666" @click="toPurchaseList()">
                    <img :src="require('assets/shop-caigou.png')" alt="">
                    <p>采购单</p>
                </div>
                <div class="jiarucaigoudan fs_32" @click="showPurchaseDialog=true">
                    加入采购单
                </div>
                <div class="xunpan fs_32" @click="showInquiryDialog=true">
                    询盘报价
                </div>
            </div>
        </div>
        <!-- <van-image-preview v-model="show" :images="images" @change="onChange">
            <template v-slot:index>第{{ index }}页</template>
        </van-image-preview> -->
        <!-- 加入采购单 -->
        <van-popup 
            class="showPurchaseDialog"
            v-model="showPurchaseDialog"
            position="bottom"
            close-icon="close"
            closeable
            :lock-scroll="true"
        >
            <div class="popup-purchase-content">
                <div class="product">
                    <img src="./meat.png" alt="">
                </div>
                <div class="description">
                    <p class="fs_26 c_333 ellipsis">{{demoSpecifications[current]}}</p>
                    <p class="fs_28 fw_600 price ellipsis">{{88.66*cartNumber || 88.66 | addCurrency('$')}}</p>
                    <p class="fs_222 c_333 ellipsis"><span class="c_666">已选：</span><span>500g/包</span>   <span>{{cartNumber || 1}}件</span></p>
                </div>
                <div class="specifications">
                    <p class="fs_28 c_333">规格</p>
                    <div class="item fs_26 c_666 clearfix">
                        <div :class="current==index?'active':''" v-for="(item, index) in demoSpecifications" :key="item" @click="current=index">{{item}}</div>
                    </div>
                </div>
                <div class="shop-num">
                    <p class="fs_28 c_333">数量</p>
                    <van-stepper v-model="cartNumber" integer  async-change @change="onChangeNum" />
                </div>
                <div class="confirm fs_32">
                    确定
                </div>
            </div>
        </van-popup>
        <!-- 询盘报价弹窗 -->
        <van-popup 
            class="showInquiryDialog"
            v-model="showInquiryDialog"
            closeable
            close-icon="close"
        >
            <div class="popup-content">
                <div class="num fs_28 c_333">
                    <p>总数量</p>
                    <div>
                        <input type="">
                        <span>KG</span>
                    </div>
                </div>
                <div class="num fs_28 c_333">
                    <p>期望价格</p>
                    <div>
                        <input type="">
                        <span>元</span>
                    </div>
                </div>
                <div class="remarks fs_28 c_333">
                    <p>备注</p>
                    <div>
                        <textarea class="c_666" name="" id="" cols="30" rows="3" placeholder="请输入您的文字"></textarea>
                    </div>
                </div>
                <div class="tips fs_28 c_333">
                    <p>温馨提示：</p>
                    <p>如您多次重复提交同一产品，系统将保留最新一次提交记录，为此给您带来的不便请您谅解！</p>
                    <p>如有疑问详情咨询<span>4000-666-591</span></p>
                </div>
                <div class="btn fs_32">
                    提交报价
                </div>
            </div>
        </van-popup>
    </div>
</template>

<script>
import Header from 'components/Header'
import Detail from './components/Detail'
import Evaluate from './components/Evaluate'
import Qa from './components/Qa'
export default {
    components: {
        'CCII-Header': Header,
        'Shop-Detail': Detail,
        'Shop-Evaluate': Evaluate,
        'Shop-Qa': Qa,
    },
    data() {
        return {
            active: 0,
            list: [],
            loading: false,
            finished: false,
            showPurchaseDialog: false, // 加入采购单
            showInquiryDialog: false, // 询盘报价
            content: 'this is detail 😂', // 详情
            total: 100,
            rate: '100%',
            evaluateList: [
                { companyName: '王小维冻品公司', say: '太好了，开心，以后有牛肉了！！！', imgs: [] }
            ],
            cartNumber: 1, // 采购单数量
            demoSpecifications: [
                '阿根廷牛腩 500g','阿根廷牛腩 700g','阿根廷牛蹄筋 500g','阿根廷听音乐吃谷物牛 500g',
            ],
            current: 0,
            // show: false,
            // index: 0,
            // images: [
            //     'https://img.yzcdn.cn/vant/apple-1.jpg',
            //     'https://img.yzcdn.cn/vant/apple-2.jpg',
            // ],
        }
    },
    mounted() {
        window.onscroll = () => {
            if (this.active === 0) {
                let scrollTop = document.documentElement.scrollTop || document.body.scrollTop
                let windowHeight = document.documentElement.clientHeight || document.body.clientHeight
                let scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight
                setTimeout(() => {
                    if (scrollHeight === scrollTop + windowHeight) {
                        this.active = 1 // 图文详情
                    }
                }, 1000);
            }
        }
    },
    methods: {
        // 采购单数量加减
        onChangeNum(value) {
            console.log(value);
            this.cartNumber = value
        },
        // onChange(index) {
        //     this.index = index;
        // },
        // 采购清单
        toPurchaseList() {
            this.$router.push({path: '/purchaseList', query: {}})
        },
        // 提交报价
        submitOffer() {

        },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.van-popup {
    overflow-y: inherit;
}
.detailsOfDomesticGoods {
    height: 100%;
    width: 100%;
    .pb120 {
        padding: 0 0 120px;
    }
    .content-box {
        background-color: #F2F1F1;
        .product-img {
            height: 650px;
            img {
                height: 100%;
                width: 100%;
            }
            .product-describe {
                height: 173px;
                margin: -43px 10px 10px;
                background-color: #fff;
                position: relative;
                padding: 20px;
                line-height: 1.4;
                .name {
                    width: 550px;
                }
                i {
                    font-size: 26px;
                }
                .price {
                    color: #FF0000;
                }
                .del {
                    position: relative;
                }
                .del::after {
                    position: absolute;
                    bottom: 15px;
                    left: 5px;
                    right: 5px;
                    height: 1px;
                    content: '';
                    transform:rotate(5deg);
                    -ms-transform:rotate(5deg);
                    -moz-transform:rotate(5deg);
                    -webkit-transform:rotate(5deg);
                    -o-transform:rotate(5deg);
                    background-color: #EE7C7C;
                }
                .status {
                    color: #FF0000;
                }
            }
        }
        .commodity-evaluation {
            background-color: #fff;
            margin: 0 10px 20px;
            .title {
                height: 64px;
                border-bottom: 1px solid #F2F1F1;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0 20px;
                .count {
                    color: #EA5520;
                }
            }
            .content {
                padding: 20px;
                border-bottom: 1px solid #F2F1F1;
                .content-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 20px;
                    img {
                        width: 50px;
                        height: 50px;
                        margin-right: 20px;
                    }
                    .company {
                        flex: 1;
                    }
                }
                .content-text {
                    padding: 0 0 0 60px;
                    P {
                        margin-bottom: 10px;
                    }
                    img {
                        width: 120px;
                        height: 120px;
                        margin-right: 10px;
                    }
                }
            }
            .more-evaluation {
                height: 50px;
                line-height: 50px;
                text-align: center;
                p {
                    color: #00428E;
                }
            }
            .no-evaluate {
                height: 80px;
                line-height: 80px;
            }
        }
        .qa {
            background-color: #fff;
            margin: 0 10px;
            .qa-title {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 64px;
                padding: 0 20px;
                border-bottom: 1px solid #F2F1F1;
                i {
                    font-size: 26px;
                }
            }
            .qa-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 60px;
                padding: 0 20px;
                border-bottom: 1px solid #F2F1F1;
                p {
                    img {
                        height: 28px;
                        margin-right: 10px;
                    }
                    span {
                        display: inline-block;
                        width: 550px;
                    }
                }
                p.num {
                    color: #EA5520;
                }
            }
            .more-qa {
                height: 50px;
                line-height: 50px;
                text-align: center;
                p {
                    color: #00428E;
                }
            }
        }
        .graphic-details {
            height: 80px;
            line-height: 80px;
            text-align: center;
            p {
                img {
                    height: 20px;
                }
            }
        }
        .footer-operation {
            position: fixed;
            bottom: 0;
            left: 0;
            display: flex;
            align-items: center;
            height: 98px;
            text-align: center;
            background-color: #fff;
            .dianpu {
                width: 141.5px;
                img {
                    height: 35px;
                    margin-bottom: 5px;
                }
            }
            .caigoudan {
                width: 141.5px;
                img {
                    height: 35px;
                    margin-bottom: 5px;
                }
            }
            .jiarucaigoudan {
                width:186px;
                height: 97px;
                line-height: 96px;
                color: #00428E;
                border:1px solid rgba(0,66,142,1);
            }
            .xunpan {
                line-height: 98px;
                width:281px;
                color: #fff;
                background:linear-gradient(183deg,rgba(33,142,237,1),rgba(3,90,190,1));
            }
        }
    }
    .showPurchaseDialog {
        width: 100%;
        min-height: 500px;
        padding: 36px 36px 0;
        .popup-purchase-content {
            position: relative;
            height: 100%;
            width: 100%;
            padding: 0 0 100px;
            .product {
                position: absolute;
                top: -80px;
                left: 5px;
                height: 214px;
                width: 321px;
                background-color: #fff;
                padding: 7px 10px;
                img {
                    margin: 0 auto;
                    height: 200px;
                    width: 300px;
                }
            }
            .description {
                width: 300px;
                margin: -15px 0 0 360px;
                line-height: 1.5;
                .price {
                    color: #FF0000;
                }
            }
            .specifications {
                margin-top: 45px;
                .item {
                    div {
                        float: left;
                        margin: 8px 10px 8px 0;
                        padding: 12px 22px;
                        border: 1px solid #EDEDED;
                    }
                    div.active {
                        color: #00418D;
                        border: 1px solid #00418D;
                    }
                }
            }
            .shop-num {
                height: 80px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .confirm {
                position: fixed;
                bottom: 0;
                left: 0;
                width:100%;
                height:86px;
                line-height: 86px;
                text-align: center;
                color: #fff;
                background:linear-gradient(83deg,rgba(33,142,237,1),rgba(2,89,190,1));
            }
        }
    }
    .showInquiryDialog{
        width: 690px;
        height: 880px;
        border-radius: 8px;
        padding: 36px;
        .popup-content {
            .num {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                height: 100px;
                p {
                    width: 140px;
                }
                div {
                    flex: 1;
                    height: 100%;
                    line-height: 95px;
                    width: 100%;
                    border-bottom: 1px solid #F2F1F1;
                    input {
                        width: 90%;
                    }
                }
            }
            .remarks {
                display: flex;
                margin: 30px 0 10px;
                p {
                    width: 140px;
                }
                div {
                    flex: 1;
                    height: 165px;
                    textarea {
                        border: 1px solid #EEEEEE;
                        padding: 20px;
                    }
                }
            }
            .tips {
                margin-bottom: 50px;
                p {
                    line-height: 1.7;
                    span {
                        color: #EA5520;
                    }
                }
            }
            .btn {
                width:500px;
                height:88px;
                line-height: 88px;
                margin: 0 auto;
                background:rgba(81,150,229,1);
                border:1px solid rgba(0,66,142,1);
                text-align: center;
                color: #fff;
            }
        }
    }
}
</style>