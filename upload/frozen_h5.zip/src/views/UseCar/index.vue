<template>
  <div>
    <CCII-Header>我要用车</CCII-Header>
    <div class="topNav">
      <div class="select"  @click="select=0">
        <div class="topImg">
          <img src="../../images/useCar/货车 (1) 拷贝 2.png" alt class="pin" />
        </div>
        <div class="bottomBg" v-show="select==0"></div>
        <img src="../../images/useCar/ping.png" alt class="jiao" />
        <div class="text" v-show="!select==0">拼车</div>
        <div class="text2" v-show="select==0">拼车</div>
      </div>
      <div class="select"  @click="select=1">
        <div class="topImg">
          <img src="../../images/useCar/货车 拷贝.png" alt class="zheng" />
        </div>
        <div class="bottomBg" v-show="select==1"></div>
        <div class="text" v-show="select!==1">整车</div>
        <div class="text2" v-show="select==1">拼车</div>
      </div>
      <div class="select" @click="select=2">
        <div class="topImg">
          <img src="../../images/useCar/货车 (1) 拷贝 3.png" alt class="ji" />
        </div>
        <div class="bottomBg" v-show="select==2"></div>
        <img src="../../images/useCar/ji.png" alt class="jiao" />
        <div class="text" v-show="select!==2">急用</div>
        <div class="text2" v-show="select==2">拼车</div>
      </div>
    </div>
  </div>
</template>

<script>
import Header from "components/Header";
export default {
  components: {
    "CCII-Header": Header
  },
  data() {
    return {
      select: 1
    };
  },
  methods: {}
};
</script>

<style lang="scss" scoped>
.topNav {
  width: 100%;
  height: 191px;
  background: url("../../images/useCar/banner.png") no-repeat;
  padding: 30px 102px;
  display: flex;
  justify-content: space-between;
  position: relative;
  .select {
    height: 100%;
    width: 144px;
    position: relative;
    .text2,
    .text {
      width: 60px;
      height: 28px;
      font-size: 28px;
      font-family: Microsoft YaHei;
      font-weight: 400;
      color: rgba(255, 255, 255, 1);

      position: absolute;
      bottom: 20px;
      left: 50%;
      margin-left: -30px;
    }
    .text2 {
      font-weight: bold;
    }
    .jiao {
      width: 34px;
      height: 34px;
      position: absolute;
      right: 0;
      top: 0;
      margin-top: -8px;
      margin-right: 17px;
    }
    .topImg {
      width: 80px;
      height: 80px;
      background: rgba(255, 255, 255, 1);
      border-radius: 8px;
      position: absolute;
      left: 50%;
      top: 0;
      margin-left: -40px;
      display: flex;
      justify-content: center;
      align-items: center;
      .pin {
        width: 61px;
        height: 26px;
      }
      .zheng {
        width: 47px;
        height: 55px;
      }
      .ji {
        width: 61px;
        height: 26px;
      }
    }
    .bottomBg {
      width: 144px;
      height: 78px;
      background: url("../../images/useCar/组 21.png") no-repeat;
      background-size: 100% 100%;
      margin-top: 53px;
    }
  }
}
</style>