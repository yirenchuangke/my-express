<template>
    <div class="gqdt">
        <CCII-Header>供求大厅</CCII-Header>
        <div class="gqdt-content">
            <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <!-- <van-tab title="冻品交易">  内容1 </van-tab> -->
                <!-- <van-tab title="冷链物流">  内容2 </van-tab> -->
                <van-tab title="冷链仓储">
                    <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        @load="onLoad"
                    >
                        <div v-for="item in list" :key="item" class="gqdt-one clearfix">
                            <img :src="require('assets/gqdt.png')" alt="">
                            <div class="gqdt-name fs_26">
                                <p class="p1 ellipsis fs_28">青岛京昌顺冷库</p>
                                <p class="p2">恒温库</p>
                                <p class="p3 ellipsis">北京市-青岛区-万花街道</p>
                            </div>
                            <div class="tr">
                                <p class="p4">可租用</p>
                                <p class="p5"><span class="fs_28 fw_600">111</span><span>平方米</span></p>
                                <p class="p6">面议</p>
                            </div>
                        </div>
                    </van-list>
                </van-tab>
                <van-tab title="冻品加工">内容 4</van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            active: 2,
            list: [],
            loading: false,
            finished: false,
        }
    },
    methods: {
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.gqdt {
    height: 100%;
    width: 100%;
    background-color: #F2F2F2;
    .gqdt-content {
        background-color: #F2F2F2;
        .gqdt-one {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 156px;
            margin: 10px;
            background-color: #fff;
            padding: 10px;
            box-shadow:1px 4px 8px 0px rgba(0, 0, 0, 0.05);
            border-radius:8px;
            img {
                height: 118px;
                width: 210px;
                margin-right: 10px;
            }
            .gqdt-name {
                flex: 1;
                width: 350px;
                .p1 {
                    color: #343434;
                }
                .p3 {
                    font-size: 20px;
                    color: #9A9A9A;
                }
            }
            .tr {
                .p4 {
                    font-size: 20px;
                    color: #9A9A9A;
                }
                .p5 {
                    span:nth-child(1) {
                        color: #EA5620;
                    }
                    span:nth-child(2) {
                        color: #343434;
                    }
                }
                .p6 {
                    color: #FF0000;
                }
            }
        }
    }
}
</style>