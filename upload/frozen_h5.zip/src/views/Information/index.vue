<template>
    <div class="information-container">
        <CCII-Header>资料编辑</CCII-Header>
        <div class="info-content">
            <div class="row">
                <span class="fs_28">头像</span>
                <div class="text tr">
                    <img :src="require('assets/gqdt.png')" alt="">
                </div>
                <i class="iconfont icon-youjiantou fw_600 c_666"></i>
            </div>
            <div class="row">
                <span class="fs_28">公司名称</span>
                <div class="text">
                    <p class="tr fs_28 c_666">国际贸易有限公司</p>
                </div>
                <!-- <i class="iconfont icon-youjiantou fw_600 c_666"></i> -->
            </div>
            <div class="row">
                <span class="fs_28">收货地址管理</span>
                <div class="text">
                    <p class="tr fs_28 c_666">北京市 朝阳区</p>
                </div>
                <i class="iconfont icon-youjiantou fw_600 c_666"></i>
            </div>
            <!-- <div class="row">
                <span class="fs_28">账户安全</span>
                <div class="text">
                    <p class="tr fs_28 c_666"></p>
                </div>
                <i class="iconfont icon-youjiantou fw_600 c_666"></i>
            </div> -->
        </div>
        <div class="safe-exit" @click="handleLogOut">安全退出</div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    },
    mounted() {

    },
    methods: {
        handleLogOut() {
            sessionStorage.clear()
            this.$store.state.userInfo = {}
            this.$store.state.hasPermission = false
            this.$router.push('/login')
        }
    }
}
</script>

<style lang="scss" scoped>
.information-container {
    width: 100%;
    height: 100%;
    background-color: #F4F4F4;
    .info-content {
        margin-top: 10px;
        .row {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            height: 110px;
            background-color: #fff;
            padding: 0 20px;
            border-bottom: 1px solid #F4F4F4;
            span {
                color: #343434;
            }
            .text {
                flex: 1;
                margin-right: 20px;
                img {
                    width: 90px;
                    height: 90px;
                    vertical-align: middle;
                }
            }
        }
    }
    .safe-exit {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        height:88px;
        line-height: 88px;
        background:rgba(255,255,255,1);
        border:1px solid rgba(255,0,0,1);
        text-align: center;
        font-size:32px;
        font-weight:bold;
        color: #FF0000;
    }
}
</style>