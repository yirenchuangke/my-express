<template>
    <div class="find-container">
        <div class="find-header c_333 fs_36">发现</div>
        <div class="find-content">
            <div class="find-content-item pd">
                <div class="item-title">
                    <p class="fs_32 c_333">常用服务</p>
                </div>
                <div class="item-detail">
                    <div class="one" @click="$router.push('/useCar')">
                        <img :src="require('assets/wyyc.png')" alt="">
                        <p>我要用车</p>
                    </div>
                    <div class="one" @click="showPopup">
                        <img :src="require('assets/jrcp.png')" alt="">
                        <p>金融产品</p>
                    </div>
                    <div class="one" @click="showPopup">
                        <img :src="require('assets/wyjg.png')" alt="">
                        <p>我要加工</p>
                    </div>
                    <div class="one" @click="$router.push('/coldStorage')">
                        <img :src="require('assets/lkyy.png')" alt="">
                        <p>冷库预约</p>
                    </div>
                    <div class="one" @click="showPopup">
                        <img :src="require('assets/gqdt.png')" alt="">
                        <p>供求大厅</p>
                    </div>
                    <div class="one" @click="showPopup">
                        <img :src="require('assets/gjmyxd.png')" alt="">
                        <p>国际贸易下单</p>
                    </div>
                </div>
            </div>
            <div class="find-content-item pd2">
                <div class="item-title">
                    <p class="fs_32 c_333">服务开通</p>
                </div>
                <div class="item-detail h148">
                    <div class="one" @click="$router.push('/openInternationalTrade')">
                        <img :src="require('assets/gjmy.png')" alt="">
                        <p>国际贸易</p>
                    </div>
                    <!-- <div class="one" @click="showPopup">
                        <img :src="require('assets/llwl.png')" alt="">
                        <p>冷链物流</p>
                    </div> -->
                    <div class="one" @click="$router.push('/openShop')">
                        <img :src="require('assets/gnsc.png')" alt="">
                        <p>国内商城</p>
                    </div>
                    <div class="one" @click="$router.push('/coldStorage')">
                        <img :src="require('assets/llcc.png')" alt="">
                        <p>冷链仓储</p>
                    </div>
                    <div class="one" @click="showPopup">
                        <img :src="require('assets/gyljr.png')" alt="">
                        <p>供应链金融</p>
                    </div>
                    <div class="one" @click="showPopup">
                        <img :src="require('assets/jgfw.png')" alt="">
                        <p>加工服务</p>
                    </div>
                </div>
            </div>
            <div class="find-content-item pd2">
                <div class="item-title">
                    <p class="fs_32 c_333">消息服务</p>
                </div>
                <div class="item-detail h148">
                    <div class="one" @click="$router.push('/enterpriseDynamics')">
                        <img :src="require('assets/qydt.png')" alt="" class="info">
                        <p>企业动态</p>
                    </div>
                    <!-- <div class="one">
                        <img :src="require('assets/sjx.png')" alt="">
                        <p>收件箱</p>
                    </div> -->
                    <div class="one" @click="$router.push('/inquiry')">
                        <img :src="require('assets/fsxx.png')" alt="" class="info">
                        <p>海外询盘</p>
                    </div>
                </div>
            </div>
            <van-popup 
                v-model="showDialog"
                closeable
                close-icon="close"
                @open="open"
                @close="close"
            >
                <div class="content">
                    <p class="p1 pd fs_32">尊敬的客户：</p>
                    <p class="p2 pd">您好！感谢您的关注，我们还在努力开发中，请您谅解！</p>
                    <p class="p3 pd">如有疑问，请拨打<span class="fs_28 fw_600">4000-666-591</span></p>
                    <p class="p4 pd fs_28"><span class="fw_600">{{seconds}}s</span>后自动关闭</p>
                    <div class="confirm" @click="close">确定</div>
                </div>
            </van-popup>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            showDialog: false,
            seconds: 60,
            timer: null,
        }
    },
    methods: {
        showPopup() {
            this.showDialog = true
        },
        open() {
            this.seconds = 60
            this.timer = setInterval(() => {
                this.seconds--
                if (this.seconds==0) {
                    this.reset()
                }
            },1000)
        },
        close() {
            this.reset()
        },
        reset() {
            this.showDialog = false
            clearInterval(this.timer)
            this.timer = null
        }
    },
    beforeDestroy() {
        this.reset()
    }
}
</script>

<style lang="scss" scoped>
.van-popup {
    width: 690px;
    height: 500px;
    border-radius:8px;
    .content {
        padding: 50px 20px;
        .pd {
            padding: 15px;
            color: #343434;
        }
        .p3 {
            color: #343434;
            span {
                color: #00428E;
            }
        }
        .p4 {
            text-align: center;
            color: #343434;
            span {
                color: #EA5620;
            }
        }
        .confirm {
            margin: 35px auto 0;
            width:500px;
            height:88px;
            line-height: 88px;
            border:1px solid #00428E;
            color: #00428E;
            border-radius:42px;
            text-align: center;
        }
    }
}
.pd {
    padding: 205px 10px 8px;
}
.pd2 {
    padding: 8px 10px;
}
.h148 {
    height: 148px!important;
}
.find-container {
    height: 100%;
    width: 100%;
    background-color: #F2F1F1;
    .find-header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 88px;
        line-height: 88px;
        background-color: #fff;
        text-align: center;
    }
    .find-content {
        padding: 88px 0 115px;
        background: url('../../assets/find-banner.png') no-repeat;
        background-position: 0 88px;
        background-size: contain;
        background-color: #F2F1F1;
        .find-content-item {
            .item-title {
                border-radius: 8px 8px 0px 0px;
                border-bottom: 1px solid #eeeeee;
                height: 88px;
                line-height: 88px;
                background-color: #fff;
                padding: 0 0 0 32px;
            }
            .item-detail {
                height:264px;
                background:rgba(255,255,255,1);
                border-radius:0px 0px 8px 8px;
                padding: 24px 0;
                .one {
                    float: left;
                    width: 146px;
                    margin: 0 0 20px;
                    img {
                        margin: 0 50px 10px; 
                        width: 50px;
                        height: 50px;
                    }
                    img.info {
                        height: 34px;
                        width: 34px;
                    }
                    p {
                        text-align: center;
                        color: #333333;
                    }
                }
            }
        }
    }
}
</style>