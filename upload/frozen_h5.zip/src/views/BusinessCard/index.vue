<template>
    <div class="businessCard-container">
        <div class="qymp">
            <div class="qymp-header fs_36">
                <i class="iconfont icon-back" @click="$router.back()"></i>企业名片<i class="iconfont icon-fenxiang" @click="showShare = true"></i>
            </div>
        </div>
        <div class="card-content">
            <div class="card-detail">
                <div class="card-img">
                    <img :src="require('assets/gqdt.png')" alt="">
                </div>
                <div class="card-content-box">
                    <p class="card-content-name c_333 fs_32 fw_600 ellipsis">北京养颐国际贸易有限公司</p>
                    <div class="line"></div>
                    <div class="card-content-item fs_24 ellipsis">
                        <p>主营业务：<span class="ellipsis c_333 fw_600">牛肉/羊肉</span></p>
                        <p>公司地址：<span class="ellipsis c_333 fw_600">北京市朝阳区CBD国际</span></p>
                        <p>联系人：<span class="ellipsis c_333 fw_600">王先生</span></p>
                        <p>联系电话：<span class="ellipsis c_333 fw_600">157 7928 2389</span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="advantages">
            <div class="advantages-title">
                <p class="c_666 fs_32">企业优势</p>
            </div>
            <div class="advantages-item">
                <div>
                    <span class="fs_28 fw_600" style="color:#FF0000">188</span>
                    <p>交易金额（万元）</p>
                </div>
                <div>
                    <span class="fs_28 fw_600" style="color:#EA5520">188</span>
                    <p>订单数量（单）</p>
                </div>
                <div>
                    <span class="fs_28 fw_600" style="color:#00428E">188</span>
                    <p>经营时长（天）</p>
                </div>
            </div>
        </div>
        <div class="advantages">
            <div class="advantages-title">
                <p class="c_666 fs_32">企业能力</p>
            </div>
            <div class="advantages-title-2">
                <p class="c_666 fs_28">国内商城</p>
            </div>
            <div class="advantages-item">
                <div>
                    <span class="fs_28 fw_600" style="color:#0757C0">188</span>
                    <p>服务企业（家）</p>
                </div>
                <div>
                    <span class="fs_28 fw_600" style="color:#FF0000">188</span>
                    <p>交易额（万元）</p>
                </div>
                <div>
                    <span class="fs_28 fw_600" style="color:#EA5520">188</span>
                    <p>订单数量（笔）</p>
                </div>
            </div>
            <div class="advantages-title-2" style="border-top:1px solid #eee">
                <p class="c_666 fs_28">仓储服务</p>
            </div>
            <div class="advantages-item">
                <div>
                    <span class="fs_28 fw_600" style="color:#0757C0">188</span>
                    <p>服务企业（家）</p>
                </div>
                <div>
                    <span class="fs_28 fw_600" style="color:#FF0000">188</span>
                    <p>交易额（万元）</p>
                </div>
                <div>
                    <span class="fs_28 fw_600" style="color:#EA5520">188</span>
                    <p>订单数量（笔）</p>
                </div>
            </div>
        </div>
        <van-share-sheet
            v-model="showShare"
            title="立即分享给好友"
            :options="options"
            @select="onSelect"
        />
    </div>
</template>

<script>
export default {
    data() {
        return {
            showShare: false,
            options: [
                { name: '微信', icon: 'wechat' },
                { name: '微博', icon: 'weibo' },
                { name: '复制链接', icon: 'link' },
                { name: '分享海报', icon: 'poster' },
                { name: '二维码', icon: 'qrcode' },
            ],
        }
    },
    methods: {
        onSelect(option) {
            this.$toast(option.name)
            this.showShare = true
        }
    }
}
</script>

<style lang="scss" scoped>
.businessCard-container {
    width: 100%;
    height: 100%;
    background: url('../../assets/qymp-bg.png') no-repeat;
    background-size: contain;
    background-color: #F4F4F4;
    .qymp {
        height: 150px;
        line-height: 150px;
        padding: 35px 0;
        .qymp-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 88px;
            padding: 0 20px;
            color: #FFFFFF;
            .iconfont {
                font-size: 40px;
            }
        }
    }
    .card-content {
        padding: 0 20px 0 30px;
        .card-detail {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            width:690px;
            height:274px;
            background:rgba(255,255,255,1);
            box-shadow:0px 4px 8px 0px rgba(0, 0, 0, 0.05);
            border-radius:8px;
            padding: 22px;
            .card-img {
                width: 170px;
                height: 170px;
                background:rgba(255,255,255,1);
                box-shadow:0px 4px 8px 0px rgba(0, 0, 0, 0.05);
                border-radius:8px;
                padding: 13px;
                margin-right: 10px;
                img {
                    width: 144px;
                    height: 144px;
                }
            }
            .card-content-box {
                .card-content-name {
                    width: 450px;
                    margin-bottom: 20px;
                }
                .line {
                    height: 1px;
                    width: 485px;
                    background-color: #EEEEEE;
                    box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.05);
                }
                .card-content-item {
                    width: 470px;
                    padding-top: 10px;
                    line-height: 1.2;
                    p {
                        position: relative;
                        span {
                            position: absolute;
                            left: 120px;
                            width: 330px;
                        }
                    }
                }
            }
        }
    }
    .advantages {
        margin: 16px 30px 16px;
        .advantages-title, .advantages-title-2{
            width:690px;
            height:80px;
            line-height: 80px;
            background:rgba(255,255,255,1);
            border-radius:8px 8px 0px 0px;
            padding: 0 0 0 19px;
            margin-bottom: 2px;
        }
        .advantages-title-2 {
            border-radius: 0;
        }
        .advantages-item {
            display: flex;
            justify-content: space-around;
            align-items: center;
            width:690px;
            height:132px;
            background:rgba(255,255,255,1);
            border-radius: 0px 0px 8px 8px;
            padding: 19px;
            div {
                width: 32%;
                border-right: 1px solid #EEEEEE;
            }
            div:nth-child(3) {
                border: none;
            }
        }
    }
}
</style>