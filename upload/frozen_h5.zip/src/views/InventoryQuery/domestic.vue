
<template>
    <div class="query-domestic">
        <van-sticky>
            <div class="header fs_32 c_333">
                <i class="iconfont icon-back fw_600" @click="$router.back()"></i>
                <p>库存查询（商城）</p>
                <p @click="$router.replace('/inventoryQuery/international')">切换</p>
            </div>
            <div class="total c_666">
                <input type="text" name="" id="" placeholder="商品名称/商品编码">
            </div>
            <van-dropdown-menu active-color="#00428E">
                <van-dropdown-item title="品类" ref="category">
                    <div class="type">
                        <p v-for="item in types" :key="item.value" :class="item.value==current?'active':''" @click="chooseItem(item.value)">{{item.name}}</p>
                    </div>
                </van-dropdown-item>
                <van-dropdown-item title="冷库" ref="freezer">
                    <div class="freezer">
                        <p v-for="item in freezers" :key="item.value" :class="item.value==currentFreezer?'ellipsis active':'ellipsis'" @click="chooseFreezer(item.value)">{{item.name}}</p>
                    </div>
                </van-dropdown-item>
            </van-dropdown-menu>
        </van-sticky>
        <div class="list">
            <van-list
                v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad"
            >
                <div class="" v-for="item in list" :key="item">
                    <div class="list-item">
                        <div class="item-l">
                            <p class="fs_26 c_666">原膳澳洲和牛西冷牛排(M4-5)150g</p>
                            <p class="name">天津中渔冷库</p>
                        </div>
                        <div class="item-r">
                            <p class="tr c_666">库存: <span class="price fs_32 fw_600">110</span> 吨</p>
                        </div>
                    </div>
                </div>
            </van-list>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            current: '',
            currentFreezer: '',
            types: [
                {name: '猪', value: 1},
                {name: '牛', value: 2},
                {name: '羊', value: 3},
                {name: '鱼', value: 4},
                {name: '虾', value: 5},
                {name: '蟹', value: 6},
            ],
            freezers: [
                {name: '天津中渔冷库', value: 1},
                {name: '青岛京昌顺冷库', value: 2},
            ],
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {

    },
    methods: {
        // 选择品类
        chooseItem(v) {
            this.current = v
            console.log(this.current);
            this.$refs.category.toggle();
        },
        // 选择冷库
        chooseFreezer(v) {
            this.currentFreezer = v
            console.log(this.currentFreezer);
            this.$refs.freezer.toggle();
        },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.query-domestic {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #fff;
        padding: 0 30px;
        border-bottom: 1px solid #F4F4F4;
        height: 88px;
        i {
            font-size: 40px;
        }
    }
    .total {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        height: 88px;
        background-color: #fff;
        padding: 20px;
        border-bottom: 1px solid #F4F4F4;
        input {
            margin: 0 auto;
            width:624px;
            height:64px;
            background:rgba(237,237,237,1);
            border-radius:32px;
            padding: 20px;
            text-align: center;
        }
    }
    .type {
        display: flex;
        justify-content: space-around;
        align-items: center;
        height: 196px;
        padding: 0 50px;
        p {
            width:74px;
            height:54px;
            line-height: 54px;
            border:1px solid #9A9A9A;
            text-align: center;
            color: #9A9A9A;
        }
        p.active {
            border:1px solid #00428E;
            text-align: center;
            color: #00428E;
        }
    }
    .freezer {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        flex-direction: column;
        padding: 20px 0;
        p {
            width:540px;
            height:54px;
            line-height: 54px;
            border:1px solid #9A9A9A;
            text-align: center;
            color: #9A9A9A;
            margin-bottom: 5px;
        }
        p.active {
            border:1px solid #00428E;
            text-align: center;
            color: #00428E;
        }
    }
    .list {
        background-color: #F4F4F4;
        padding: 10px 0 0;
        .list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 110px;
            background-color: #fff;
            margin: 10px;
            padding: 10px;
            line-height: 1.5;
            .item-l {
                .name {
                    color: #9A9A9A;
                }
            }
            .item-r {
                p {
                    .price {
                        color: #FF0000;
                    }
                }
            }
        }
    }
}
</style>