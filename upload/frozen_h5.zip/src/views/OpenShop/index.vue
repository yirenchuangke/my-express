<template>
    <div class="openShop-form">
        <CCII-Header>商城店铺开通</CCII-Header>
        <div class="form-content">
            <van-form @submit="onSubmit">
                <van-field
                    v-model="name"
                    name="店铺名称"
                    label="店铺名称"
                    placeholder="请输入店铺名称"
                    :rules="[{ required: true, message: '店铺名称' }]"
                />
                <van-field
                    v-model="level"
                    readonly
                    type="tel"
                    name="店铺等级"
                    label="店铺等级"
                    placeholder="请选择店铺等级"
                    :rules="[{ required: true, message: '店铺等级' }]"
                    @click="showStoreLevel=true"
                />
                <van-field
                    v-model="email"
                    type="text"
                    name="邮箱地址"
                    label="邮箱地址"
                    placeholder="请输入邮箱地址"
                    :rules="[{ required: true, message: '邮箱地址' }]"
                />
                <van-field
                    v-model="mobile"
                    type="text"
                    name="联系电话"
                    label="联系电话"
                    placeholder="请输入联系电话"
                    :rules="[{ required: true, message: '联系电话' }]"
                />
                <van-popup v-model="showStoreLevel" position="bottom">
                    <van-picker
                        ref="dd"
                        show-toolbar
                        :columns="levels"
                        value-key="name"
                        @cancel="showStoreLevel = false"
                        @confirm="onConfirm"
                    />
                </van-popup>
                <!-- <div class="save">
                    <van-button native-type="submit">
                        确定
                    </van-button>
                </div> -->
            </van-form>
        </div>
        <div class="save" @click="save">
            <p class="fs_28">确定</p>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            name: '',
            level: '',
            email: '',
            mobile: '',
            showStoreLevel: false,
            levels: [{id:1,name:'金牌'}, {id:1,name:'银牌'}, {id:3,name:'铜牌'}],
        }
    },
    methods: {
        onSubmit(values) {
            console.log('submit', values);
        },
        onConfirm(value) {
            // console.log(value,this.$refs.dd.getValues());
            this.level = value.name;
            this.showStoreLevel = false;
        },
        save() {
            
        }
    },
}
</script>

<style lang="scss" scoped>
.openShop-form {
    height: 100%;
    width: 100%;
    background-color: #F2F1F1;
    .form-content {
        // height: 100%;
        background-color: #FFFFFF;
        margin: 10px 0 98px;
        .van-cell {
            height: 110px;
            line-height: 110px;
        }
    }
    .save {
        position: fixed;
        bottom: 0;
        left: 0;
        width:100%;
        height:98px;
        line-height: 98px;
        text-align: center;
        color: #FFFFFF;
        background:linear-gradient(13deg,rgba(33,142,237,1),rgba(3,90,190,1));
    }
}
</style>

<style>
.van-field__label {
    width: 120px;
}
</style>