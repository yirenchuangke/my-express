<template>
    <div class="shoplist">
        <van-sticky>
            <div class="switch">
                <i class="iconfont icon-zuojiantou fw_600" @click="$router.back()"></i>
                <div>
                    <span :class="index==0?'bg':''" ref="hwcs" @click="handleSwitch(0)">海外厂商百科</span>
                    <span :class="index==1?'bg':''" ref="scdp" @click="handleSwitch(1)">商城店铺</span>
                </div>
                <div></div>
            </div>
            <van-dropdown-menu active-color="#00428E">
                <van-dropdown-item title="区域" ref="freezer">
                    <div class="freezer">
                        <van-tree-select
                            height="200"
                            :items="items"
                            :active-id.sync="activeId"
                            :main-active-index.sync="activeIndex"
                            @click-nav="chooseContinent"
                            @click-item="chooseCountry"
                        />
                    </div>
                </van-dropdown-item>
                <van-dropdown-item title="品类" ref="category">
                    <div class="type">
                        <p v-for="item in types" :key="item.value" :class="item.value==current?'active':''" @click="chooseItem(item.value)">{{item.name}}</p>
                    </div>
                </van-dropdown-item>
            </van-dropdown-menu>
        </van-sticky>
        <div class="list">
            <van-list
                v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad"
            >
                <div v-for="item in list" :key="item.src">
                    <div class="list-item" @click="toStorePage">
                        <img :src="require('assets/gqdt.png')" alt="">
                        <div class="ellipsis">
                            <p class="fs_26 c_333 ellipsis">{{item.name}}</p>
                            <p class="c_666 ellipsis">{{item.b}}</p>
                            <p class="c_666 ellipsis">{{item.c}}</p>
                        </div>
                    </div>
                </div>
            </van-list>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            index: 0,
            current: '',
            types: [
                {name: '猪', value: 1},
                {name: '牛', value: 2},
                {name: '羊', value: 3},
                {name: '鱼', value: 4},
                {name: '虾', value: 5},
                {name: '蟹', value: 6},
            ],
            items: [
                {
                    text: '亚洲',
                    children: [
                        {
                            text: '中国',
                            id: 1,
                        },
                        {
                            text: '朝鲜',
                            id: 2,
                        },
                    ],
                },
                {
                    text: '欧洲'
                },{
                    text: '美洲'
                },{
                    text: '非洲'
                },{
                    text: '大洋洲'
                },
            ],
            activeId: 1,
            activeIndex: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {
        this.index = this.$route.query.index || 0
    },
    methods: {
        // 顶部切换
        handleSwitch(v) {
            this.index = v
            if (this.index == 0) {
                this.list = [{name: '阿根廷进口京精品牛一把(国外)',b:'主营：猪、牛、羊、鱼、虾、贝',c:'厂号：bl55205'}]
            } else {
                this.list = [{name: '阿根廷进口京精品牛一把(国内)',b:'主营：猪、牛、羊、鱼、虾、贝',c:'厂号：bl55205'}]
            }
            this.onLoad()
        },
        // 选择品类
        chooseItem(v) {
            this.current = v
            console.log(this.current);
            this.$refs.category.toggle();
        },
        // 选择大洲
        chooseContinent() {
            console.log(this.activeIndex)
        },
        // 选择国家
        chooseCountry() {
            console.log(this.activeId)
            this.$refs.freezer.toggle();
        },
        // 去国外或国内的具体店铺页面
        toStorePage() {
            if (this.index == 0) {
                this.$router.push({path: '/internationalStoresList', query: {}})
            } else {
                this.$router.push({path: '/domesticStoresList', query: {}})
            }
        },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 5; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 5) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.shoplist {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .switch {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height:80px;
        background-color: #fff;
        border-top: 1px solid #F4F4F4;
        border-bottom: 1px solid #F4F4F4;
        text-align: center;
        padding: 0 20px;
        i {
            font-weight: 600;
            font-size: 40px;
        }
        div {
            span {
                display: inline-block;
                font-size: 26px;
                color: #666666;
                width:186px;
                height:54px;
                line-height: 54px;
                border: 1px solid #EEEEEE;
            }
            span.bg {
                background-color: #EEEEEE;
            }
            span:active {
                background-color: #EEEEEE;
            }
        }
    }
    .type {
        display: flex;
        justify-content: space-around;
        align-items: center;
        height: 196px;
        padding: 0 50px;
        p {
            width:74px;
            height:54px;
            line-height: 54px;
            border:1px solid #9A9A9A;
            text-align: center;
            color: #9A9A9A;
        }
        p.active {
            border:1px solid #00428E;
            text-align: center;
            color: #00428E;
        }
    }
    .list {
        background-color: #F4F4F4;
        .list-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            height: 160px;
            padding: 20px;
            margin: 20px;
            img {
                height: 120px;
                width: 240px;
                margin-right: 20px;
            }
            div {
                flex: 1;
                p {
                    padding: 5px;
                }
            }
        }
    }
}
</style>