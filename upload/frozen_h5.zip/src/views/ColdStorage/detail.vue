<template>
    <div class="coldstorage-detail">
        <CCII-Header>冷库详情</CCII-Header>
        <div class="content">
            <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
                <van-swipe-item><img src="./test.png" alt=""></van-swipe-item>
                <van-swipe-item><img src="./test1.png" alt=""></van-swipe-item>
            </van-swipe>
            <div class="coldstorage-name">
                <div class="left">
                    <p class="fs_36 c_333 ellipsis">天津中渔冷库</p>
                    <p class="c_333 ellipsis">编号：r20190101001</p>
                    <p class="fs_28 c_999 address ellipsis">天津市滨海新区海容路95号</p>
                    <p class="price"><span class="fs_36 fw_600 ellipsis">￥460 </span><del class="fs_28">￥660</del><span class="fs_28 c_333 fw_600">   天/吨</span></p>
                    <div class="tag clearfix"><p class="fl">租赁服务</p><p class="fl">仓储服务</p></div>
                </div>
                <div class="right tc">
                    <p class="fs_36 num fw_600 ellipsis">999+</p>
                    <p class="num">用户评价</p>
                    <p class="c_666"><span class="see">查看</span></p>
                    <p class="c_666"><i class="iconfont icon-shoucang"></i> 收藏</p>
                </div>
            </div>
            <div class="colestorage-map">
                <div class="innerbox">
                    <div class="title">
                        <p class="fs_28 c_333">仓库位置|</p>
                    </div>
                    <div class="map-img">
                        This is coldStorage map!
                    </div>
                </div>
            </div>
            <div class="coldstorage-item">
                <p><span class="left">公司名称：</span><span class="c_333">天津中渔置业有限公司</span></p>
                <p><span class="left">建造时间：</span><span class="c_333">2012年4月</span></p>
                <p><span class="left">占地面积：</span><span class="c_333">80000平方米</span></p>
                <p><span class="left">冷库总容量：</span><span class="c_333">5.5万吨</span></p>
                <p><span class="left">冷库类型：</span></p>
                <p><span class="left">温度区间：</span></p>
                <p><span class="left">是否有检验资格：</span><span class="c_333">是</span></p>
                <p><span class="left">是否是保税库：</span><span class="c_333">否</span></p>
            </div>
        </div>
        <div class="coldstorage-footer fs_32 clearfix" @click="showPopup">
            <div class="fl">立即入库</div>
            <div class="fr">预约看仓</div>
        </div>
        <van-popup 
            v-model="showDialog"
            closeable
            close-icon="close"
            @open="open"
            @close="close"
        >
            <div class="dialog-content">
                <p class="p1 pd fs_32">尊敬的客户：</p>
                <p class="p2 pd">您好！感谢您的关注，我们还在努力开发中，请您谅解！</p>
                <p class="p3 pd">如有疑问，请拨打<span class="fs_28 fw_600">4000-666-591</span></p>
                <p class="p4 pd fs_28"><span class="fw_600">{{seconds}}s</span>后自动关闭</p>
                <div class="confirm" @click="close">确定</div>
            </div>
        </van-popup>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            showDialog: false,
            seconds: 60,
            timer: null,
        }
    },
    mounted() {

    },
    methods: {
        showPopup() {
            this.showDialog = true
        },
        open() {
            this.seconds = 60
            this.timer = setInterval(() => {
                this.seconds--
                if (this.seconds==0) {
                    this.reset()
                }
            },1000)
        },
        close() {
            this.reset()
        },
        reset() {
            this.showDialog = false
            clearInterval(this.timer)
            this.timer = null
        }
    },
    beforeDestroy() {
        this.reset()
    }
}
</script>

<style lang="scss" scoped>
.van-popup {
    width: 690px;
    height: 500px;
    border-radius:8px;
    .dialog-content {
        padding: 50px 20px;
        .pd {
            padding: 15px;
            color: #343434;
        }
        .p3 {
            color: #343434;
            span {
                color: #00428E;
            }
        }
        .p4 {
            text-align: center;
            color: #343434;
            span {
                color: #EA5620;
            }
        }
        .confirm {
            margin: 35px auto 0;
            width:500px;
            height:88px;
            line-height: 88px;
            border:1px solid #00428E;
            color: #00428E;
            border-radius:42px;
            text-align: center;
        }
    }
}
.coldstorage-detail {
    height: 100%;
    width: 100%;
    background-color: #F2F1F1;
    .content {
        position: relative;
        padding: 0 0 94px;
        img {
            height: 500px;
            width: 100%;
        }
        .coldstorage-name {
            position: absolute;
            top: 460px;
            left: 10px;
            height: 315px;
            width: 730px;
            background-color: #fff;
            border-radius:8px;
            padding: 25px;
            display: flex;
            justify-content: space-between;
            .left {
                flex: 1;
                width: 550px;
                p {
                    line-height: 1.8;
                }
                p.price {
                    color: #CBCBCB;
                }
                div.tag {
                    p {
                        color: #00418D;
                        border: 1px solid #00418D;
                        border-radius: 4px;
                        margin-right: 20px;
                        padding: 0px 5px;
                    }
                }
            }
            .right {
                width: 127px;
                border-left: 1px solid #EDEDED;
                p {
                    line-height: 2.5;
                    span.see {
                        padding: 2px;
                        color: #656565;
                        border: 1px solid #656565;
                        border-radius: 4px;
                    }
                }
                p.num {
                    color: #eeeeee;
                }
            }
        }
        .colestorage-map {
            margin: 280px 0 20px;
            height: 545px;
            width: 100%;
            background-color: #F2F1F1;
            .innerbox {
                height: 97%;
                background-color: #fff;
                .title {
                    height: 89px;
                    line-height: 89px;
                    padding: 0 30px;
                    margin-bottom: 16px;
                    p {
                        border-bottom: 1px solid #EDEDED;
                    }
                }
                .map-img {
                    padding: 0 24px;
                    height: 376px;
                    width: 100%;
                }
            }
        }
        .coldstorage-item {
            background-color: #fff;
            padding: 20px 30px;
            p {
                line-height: 2;
                span.left {
                    display: inline-block;
                    color: #666;
                    width: 200px;
                }
            }
        }
    }
    .coldstorage-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        background-color: #fff;
        height: 94px;
        line-height: 94px;
        width: 100%;
        text-align: center;
        .fl {
            width: 300px;
            color: #00428E;
            border-left: 1px solid #00428E;
            border-top: 1px solid #00428E;
        }
        .fr {
            width: 450px;
            background:linear-gradient(183deg,rgba(33,142,237,1),rgba(3,90,190,1));
            color: #fff;
        }
    }
}
</style>