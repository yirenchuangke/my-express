<template>
    <div class="coldStorage">
        <div class="header">
            <i class="iconfont icon-zuojiantou" @click="$router.back()"></i>
            <div class="search">
                <input type="text" placeholder="搜索各大集群冷库信息">
                <i class="iconfont icon-sousuo"></i>
            </div>
        </div>
        <div class="content">
            <!-- <van-tree-select height="100%" :items="items" :main-active-index.sync="active">
                <template #content>
                    <van-image
                        v-if="active === 0"
                        src="https://img.yzcdn.cn/vant/apple-1.jpg"
                    />
                    <van-image
                        v-if="active === 1"
                        src="https://img.yzcdn.cn/vant/apple-2.jpg"
                    />
                </template>
            </van-tree-select> -->
            <div class="left">
                <ul>
                    <li :class="current==index?'ellipsis active':''" v-for="(item, index) in testList" :key="item.id" @click="current=index">{{item.value}}</li>
                </ul>
            </div>
            <div class="right">
                <!-- <van-sticky :offset-top="44"> -->
                    <div class="top">
                        <img src="./test.png" alt="">
                        <div class="text">
                            <span class="c_333">{{testList[current].value}}</span>
                            <!-- <div class="line"></div> -->
                        </div>
                    </div>
                <!-- </van-sticky> -->
                <div class="store-list clearfix">
                    <div class="fl item" v-for="item in 5" :key="item" @click="$router.push('/coldStorage/detail')">
                        <img src="./test.png" alt="">
                        <p class="ellipsis fs_22 c_666">天津中渔置业有限公司</p>
                        <p class="ellipsis fs_20 c_999">冷冻仓 | 容量：13000吨</p>
                        <p class="ellipsis fs_20 c_999"><i class="iconfont icon-dizhi"></i> 河北省-廊坊市-广阳区</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            // active: 0,
            // items: [{ text: '分组 1' }, { text: '分组 2' }],
            current: 0,
            testList: [
                { id: 0, value: '全部' },
                { id: 1, value: '天津' },
                { id: 2, value: '上海' },
                { id: 3, value: '青岛' },
                { id: 4, value: '大连' },
                { id: 5, value: '宁波' },
                { id: 6, value: '海口' },
                { id: 7, value: '广州' },
                { id: 8, value: '深圳' },
                { id: 9, value: '香港' },
            ]
        }
    },
    mounted() {

    },
    methods: {

    }
}
</script>

<style lang="scss" scoped>
.coldStorage {
    height: 100%;
    width: 100%;
    background-color: #fff;
    .header {
        position: fixed;
        top: 0;
        left: 0;
        background-color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 88px;
        border-bottom: 1px solid #EDEDED;
        padding: 0 30px;
        z-index: 999999;
        .icon-zuojiantou:before {
            color: #999999;
            font-size: 40px;
            font-weight: 600;
            margin-right: 30px;
        }
        .search {
            flex: 1;
            position: relative;
            input {
                width:624px;
                height:64px;
                background-color: #EDEDED;
                border-radius:32px;
                text-align: center;
                font-size: 26px;
            }
            .icon-sousuo:before {
                position: absolute;
                top: 10px;
                left: 130px;
                color: #999999;
                font-size: 44px;
                font-weight: 600;
            }
        }
    }
    .content {
        padding: 88px 0 0;
        display: flex;
        // height: 100%;
        .left {
            width: 168px;
            ul {
                text-align: center;
                overflow-y: scroll;
                li {
                    font-size: 28px;
                    color: #666666;
                    padding: 30px 0;
                    width: 100%;
                    letter-spacing: 10px;
                }
                li.active {
                    color: #0359BD;
                }
            }
        }
        .right {
            flex: 1;
            background-color: #EDEDED;
            .top {
                height: 300px;
                background-color: #fff;
                padding: 30px 27px 0;
                img {
                    height: 192px;
                    width: 528px;
                }
                .text {
                    text-align: center;
                    padding: 0 55px;
                    line-height: 2.5;
                    span {
                        position: relative;
                        margin: 16px 30px 0;
                    }
                    span::after {
                        content: '';
                        width: 100px;
                        height: 1px;
                        background-color: #EDEDED;
                        position: absolute;
                        bottom: 12px;
                        left: 80px;
                    }
                    span::before {
                        content: '';
                        width: 100px;
                        height: 1px;
                        background-color: #EDEDED;
                        position: absolute;
                        bottom: 12px;
                        left: -132px;
                    }
                }
            }
            .store-list {
                padding: 10px;
                .item {
                    height: 316px;
                    width: 258px;
                    background-color: #fff;
                    margin: 10px;
                    padding: 5px;
                    img {
                        height: 181px;
                        width: 242px;
                        margin: 4px 4px 0;
                    }
                    p {
                        line-height: 1.5;
                        .icon-dizhi:before {
                            color: #00418D;
                            font-size: 26px;
                        }
                    }
                }
            }
        }
    }
}
</style>