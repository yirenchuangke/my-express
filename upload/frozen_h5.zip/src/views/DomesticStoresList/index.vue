<template>
    <div class="domesticStoreList-box">
        <div class="header">
            <i class="iconfont icon-zuojiantou" @click="$router.back()"></i>
            <div class="search">
                <input type="text" placeholder="进口牛肉" @focus="toSearch">
                <i class="iconfont icon-sousuo"></i>
            </div>
        </div>
        <div class="content">
            <div class="store">
                <div class="imgbox"><img :src="require('assets/gqdt.png')" alt=""></div>
                <div class="text">
                    <p class="fs_26 c_333 ellipsis">大连广龙</p>
                    <p class="fs_22 c_666 ellipsis">主营：猪、牛、羊、鱼、虾、贝</p>
                    <p class="fs_22 c_666 ellipsis">所在地：大连市广龙区</p>
                </div>
                <div class="collection">收藏</div>
            </div>
            <div class="store-img">
                <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
                    <van-swipe-item><img src="./test.png" alt=""></van-swipe-item>
                    <van-swipe-item><img src="./test.png" alt=""></van-swipe-item>
                </van-swipe>
            </div>
        </div>
        <van-sticky :offset-top="44">
            <div class="tab fs_28">
                <div :class="currentTab==0?'item c_333':'item c_666'" @click="currentTab=0">推荐</div>
                <div :class="currentTab==1?'item c_333':'item c_666'" @click="currentTab=1">销量</div>
                <div :class="currentTab==2?'item c_333':'item c_666'" @click="[currentTab=2,price=='up'?price='down':price='up']">价格<i :class="price=='up'?'iconfont icon-xiajiantou':'iconfont icon-jiantouarrow492'"></i></div>
            </div>
        </van-sticky>
        <div class="storelist">
            <van-list
                v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad"
            >
                <div class="categories-one clearfix" v-for="item in list" :key="item" @click="$router.push('/detailsOfDomesticGoods')">
                    <img class="fl" :src="require('assets/gqdt.png')" alt="logo" />
                    <div class="categories-detail fl">
                        <p class="title ellipsis">原膳澳洲精修牛腱子</p>
                        <p class="price">{{88.66 | addCurrency('$')}}</p>
                        <p class="specifications ellipsis"><span>规格：无骨</span><span>起批发：10公斤</span></p>
                        <p class="address"><span class="shipping-address fl ellipsis">发货地址：天津市天津中渔冷库</span><span class="stock fr">现货</span></p>
                    </div>
                </div>
            </van-list>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            currentTab: 0,
            price: 'up',
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {

    },
    methods: {
        toSearch() {
            this.$router.push('/search')
        },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.domesticStoreList-box {
    height: 100%;
    width: 100%;
    background-color: #fff;
    .header {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 99999;
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 88px;
        width: 100%;
        padding: 0 20px;
        border-bottom: 1px solid #EEEEEE;
        background-color: #fff;
        i {
            color: #333333;
            font-size: 40px;
            font-weight: 600;
        }
        .search {
            flex: 1;
            position: relative;
            input {
                width: 600px;
                height: 54px;
                border-radius: 27px;
                margin-left: 20px;
                border: 1px solid #EEEEEE;
                padding: 0 25px 0 50px;
                color: #999999;
                background-color: #EEEEEE;
            }
            .icon-sousuo:before {
                position: absolute;
                top: 8px;
                left: 30px;
                color: #999999;
            }
        }
    }
    .content {
        padding: 88px 0 0;
        .store {
            height: 132px;
            background-color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 30px;
            .imgbox {
                width:188px;
                height:94px;
                background:rgba(255,255,255,1);
                border:1px solid rgba(238,238,238,1);
                margin-right: 15px;
                img {
                    height: 74px;
                    width: 106px;
                    margin: 10px 41px;
                }
            }
            .text {
                flex: 1;
                width: 380px;
            }
            .collection {
                width:93px;
                height:54px;
                line-height: 54px;
                border:1px solid #EA5520;
                border-radius:27px;
                text-align: center;
                color: #EA5520;
            }
        }
        .store-img {
            img {
                height: 340px;
                width: 100%;
            }
        }
    }
    .tab {
        height: 80px;
        background-color: #fff;
        display: flex;
        justify-content: space-around;
        align-items: center;
        div.item {
            text-align: center;
            height: 100%;
            line-height: 80px;
            width: 33.33%;
            border-right: 1px solid #F2F1F1;
            i {
                font-size: 30px;
            }
        }
    }
    .storelist {
        background-color: #F2F1F1;
        padding: 10px;
        .categories-one {
            height:208px;
            margin-bottom: 10px;
            background:rgba(255,255,255,1);
            box-shadow:0px 4px 8px 0px rgba(0, 0, 0, 0.05);
            padding: 25px;
            img {
                width: 168px;
                height: 168px;
                margin-right: 10px;
            }
            .categories-detail {
                width: 480px;
                font-size: 28px;
                line-height: 1.5;
                .title {
                    color: #333333;
                    font-weight: 600;
                    margin-bottom: 5px;
                }
                .price {
                    color: #FF0000;
                    font-weight: 600;
                }
                .specifications {
                    color: #999999;
                    font-size: 24px;
                    span {
                        margin-right: 15px;
                    }
                }
                .address {
                    color: #999999;
                    font-size: 24px;
                    .shipping-address {
                        display: block;
                        width: 400px;
                    }
                    .stock {
                        color: #FF0000;
                        font-weight: 600;
                        right: 30px;
                    }
                }
            }
        }
    }
}
</style>