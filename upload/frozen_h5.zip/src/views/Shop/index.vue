<template>
    <div class="shop-container">
        <div class="shop-search-bar">
            <div class="search-input">
                <input type="text" placeholder="请输入搜索关键词">
                <i class="iconfont icon-sousuo"></i>
            </div>
            <!-- <van-search
                placeholder="输入公司或职位"
                show-action
                :background="backgroundColor"
                shape="round"
                >
                <div slot="action">搜索</div>
            </van-search> -->
        </div>
        <div class="shop-body">
            <div class="shop-banner">
                <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
                    <van-swipe-item><img src="./banner.png" alt=""></van-swipe-item>
                    <van-swipe-item><img src="./banner.png" alt=""></van-swipe-item>
                    <van-swipe-item><img src="./banner.png" alt=""></van-swipe-item>
                </van-swipe>
            </div>
            <div class="shop-ad">
                <img :src="require('assets/shangcheng-img.png')" alt="logo" @click="toShopList(0)" />
                <img :src="require('assets/shangcheng-img2.png')" alt="logo" @click="toShopList(1)" />
            </div>
            <div class="shop-categories">
                <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="7">
                    <van-tab title="精选">
                        <van-list
                            v-model="loading"
                            :finished="finished"
                            finished-text="没有更多了"
                            @load="onLoad"
                        >
                            <div class="categories-one clearfix" v-for="item in list" :key="item" @click="$router.push('/detailsOfDomesticGoods')">
                                <img class="fl" :src="require('assets/gqdt.png')" alt="logo" />
                                <div class="categories-detail fl">
                                    <p class="title ellipsis">原膳澳洲精修牛腱子</p>
                                    <p class="price">{{88.66 | addCurrency('$')}}</p>
                                    <p class="specifications ellipsis"><span>规格：无骨</span><span>起批发：10公斤</span></p>
                                    <p class="address"><span class="shipping-address fl ellipsis">发货地址：天津市天津中渔冷库</span><span class="stock fr">现货</span></p>
                                </div>
                            </div>
                        </van-list>
                    </van-tab>
                    <van-tab title="猪肉">内容 2</van-tab>
                    <van-tab title="牛肉">内容 3</van-tab>
                    <van-tab title="羊肉">内容 4</van-tab>
                    <van-tab title="鱼类">内容 5</van-tab>
                    <van-tab title="虾类">内容 6</van-tab>
                    <van-tab title="蟹类">内容 7</van-tab>
                </van-tabs>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {
        window.addEventListener("scroll", this.handleScroll);
    },
    methods: {
        toShopList(index) {
            this.$router.push({path: '/shopList', query:{index}})
        },
        handleScroll() {
            let docSearch = document.querySelector(".shop-search-bar")
            let docInput = document.querySelector(".shop-search-bar input")
            let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
            // let offsetTop = docSearch.offsetTop;
            // console.log(offsetTop,scrollTop)
            if (scrollTop) {
                docSearch.style.backgroundColor = `rgba(255, 255, 255,${scrollTop / (scrollTop + 20)})`;
                docInput.style.backgroundColor = `rgba(244, 244, 244,${scrollTop / (scrollTop + 20)})`;
            } else if (scrollTop == 0) {
                docSearch.style.backgroundColor = "";
            }
        },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    },
    activated() {
        window.addEventListener("scroll", this.handleScroll);
    },
    deactivated() {
        window.removeEventListener("scroll", this.handleScroll);
    }
}
</script>

<style lang="scss" scoped>
$--footer-height: 110px;
.shop-container {
    height: 100%;
    background: url('../../assets/shop-bg.png') no-repeat;
    background-size: contain;
    .shop-search-bar {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999;
        width: 100%;
        height: 88px;
        line-height: 88px;
        .search-input {
            position: relative;
            height: 88px;
            input {
                width:692px;
                height:54px;
                background-color: rgba(244, 244, 244, .2);
                border: 1px solid rgba(244, 244, 244, .2);
                border-radius:27px;
                padding: 10px 50px 10px 55px;
                font-size: 24px;
                color: #CCCCCC;
                margin: 16px 26px;
                color: #333;
            }
            .icon-sousuo:before {
                position: absolute;
                top: 0px;
                left: 40px;
                font-size: 40px;
            }
        }
    }
    .shop-body {
        padding: 108px 0 130px;
        .shop-banner {
            margin: 0 30px 30px;
            height: 340px;
            width: 690px;
            background-color: pink;
            img {
                height: 100%;
                width: 100%;
            }
        }
        .shop-ad {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin: 30px;
            height: 202px;
            width: 690px;
            background:rgba(255,255,255,1);
            box-shadow:0px 4px 8px 0px rgba(0, 0, 0, 0.05);
            border-radius:8px;
            padding: 10px;
            img {
                width: 328px;
                height: 170px;
            }
        }
        .shop-categories {
            .categories-one {
                margin: 30px;
                height:208px;
                background:rgba(255,255,255,1);
                box-shadow:0px 4px 8px 0px rgba(0, 0, 0, 0.05);
                border-radius:8px;
                padding: 15px 10px;
                img {
                    width: 168px;
                    height: 168px;
                    margin-right: 10px;
                }
                .categories-detail {
                    width: 480px;
                    font-size: 28px;
                    line-height: 1.5;
                    .title {
                        color: #333333;
                        font-weight: 600;
                        margin-bottom: 5px;
                    }
                    .price {
                        color: #FF0000;
                        font-weight: 600;
                    }
                    .specifications {
                        color: #999999;
                        font-size: 24px;
                        span {
                            margin-right: 15px;
                        }
                    }
                    .address {
                        color: #999999;
                        font-size: 24px;
                        .shipping-address {
                            display: block;
                            width: 400px;
                        }
                        .stock {
                            color: #FF0000;
                            font-weight: 600;
                            right: 30px;
                        }
                    }
                }
            }
        }
    }
}
</style>