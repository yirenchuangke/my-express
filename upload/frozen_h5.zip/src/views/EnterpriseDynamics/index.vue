<template>
    <div class="enterprise">
        <CCII-Header>企业动态</CCII-Header>
        <div class="content">
            <div class="item">
                <i class="abs"><span class="dot"></span></i>
                <p class="fs_22 c_666">2019-08-06 23:00:00</p>
                <p class="p2 fw_600 ellipsis">新增订单：北京融界数据科技有限公司订单</p>
                <p class="fs_22 c_666">操作人：张冉<span class="fr">所属部门：销售部</span></p>
            </div>
            <div class="item">
                <i class="abs"><span class="circle"></span></i>
                <p class="fs_22 c_666">2019-08-06 23:00:00</p>
                <p class="p2 fw_600 ellipsis">新增订单：北京融界数据科技有限公司订单</p>
                <p class="fs_22 c_666">操作人：张冉<span class="fr">所属部门：销售部</span></p>
            </div>
            <div class="item">
                <i class="abs"><span class="dot"></span></i>
                <p class="fs_22 c_666">2019-08-06 23:00:00</p>
                <p class="p2 fw_600 ellipsis">新增订单：北京融界数据科技有限公司订单</p>
                <p class="fs_22 c_666">操作人：张冉<span class="fr">所属部门：销售部</span></p>
            </div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.enterprise {
    height: 100%;
    width: 100%;
    .content {
        padding: 20px 20px 20px 60px;
        line-height: 1.5;
        .item {
            position: relative;
            height: 130px;
            border: 1px solid #EEEEEE;
            margin-bottom: 20px;
            padding: 10px;
            .p2 {
                color: #343434;
            }
            .abs {
                position: absolute;
                top: 50%;
                left: -30px;
                height: 150px;
                border-left: 1px solid #EA5620;
                span.dot {
                    position: absolute;
                    display: inline-block;
                    height: 24px;
                    width: 24px;
                    background-color: #E25A28;
                    border-radius: 50%;
                    left: -12px;
                }
                span.circle {
                    position: absolute;
                    display: inline-block;
                    height: 16px;
                    width: 16px;
                    border: 1px solid #E25A28;
                    background-color: #fff;
                    border-radius: 50%;
                    left: -8px;
                }
            }
        }
    }
}
</style>