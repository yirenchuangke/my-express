<template>
    <div class="logisticsOrder">
        <CCII-Header>物流订单</CCII-Header>
        <div class="logisticsOrder-content">
            <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="全部">
                    <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        @load="onLoad"
                    >
                        <div class="" v-for="item in 1" :key="item">
                            <div class="item clearfix">
                                <div class="item-title">
                                    <p class="c_666">运单号：<span>DP20200506625010</span></p>
                                </div>
                                <div class="item-content" @click="$router.push('/logisticsOrder/detail')">
                                    <div class="l">
                                        <p class="fs_30 fw_600">天津市</p>
                                        <p class="area">天津中渔冷库</p>
                                    </div>
                                    <div class="m">
                                        <img :src="require('assets/yongche1.png')" alt="">
                                        <!-- <img :src="require('assets/yongche.png')" alt=""> -->
                                        <p class="daizhifu fw_600">待支付</p>
                                    </div>
                                    <div class="r"> 
                                        <p class="fs_30 fw_600">天津市</p>
                                        <p class="area">天津中渔冷库</p>
                                    </div>
                                </div>
                                <div class="item-time">
                                    <p class="fs_20 c_666">下单时间：<span class="time">2020-05-06  14:18</span></p>
                                </div>
                                <!-- 根据状态显隐div -->
                                <div class="item-operation">
                                    <div class="pay">支付</div>
                                    <div class="cancel" @click="showPopup">取消订单</div>
                                    <div class="edit" @click="showPopup">修改订单</div>
                                </div>
                            </div>
                        </div>
                    </van-list>
                </van-tab>
                <van-tab title="运输中">内容 2</van-tab>
                <van-tab title="已完成">内容 3</van-tab>
            </van-tabs>
        </div>
        <van-popup 
            v-model="showDialog"
            closeable
        >
            <div class="content">
                <p class="p1 fw_600 fs_28">如需<span>取消（或修改）</span></p>
                <p class="fs_30 tel">请致电：400-9000-6222</p>
            </div>
        </van-popup>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },  
    data() {
        return {
            showDialog: false,
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {
        this.active = this.$route.query.index || 0
    },
    methods: {
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
        // 取消修改订单
        showPopup() {
            this.showDialog = true
        },
    }
}
</script>

<style lang="scss" scoped>
.logisticsOrder {
    width: 100%;
    height: 100%;
    background-color: #F4F4F4;
    .logisticsOrder-content {
        background-color: #F4F4F4;
        .item {
            margin: 20px;
            background-color: #fff;
            border-radius: 8px;
            .item-title {
                height: 80px;
                line-height: 80px;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
                span {
                    color: #343434;
                }
            }
            .item-content {
                display: flex;
                justify-content: space-around;
                align-items: center;
                height: 110px;
                border-bottom: 1px solid #F4F4F4;
                .l {
                    .area {
                        color: #9A9A9A;
                    }
                }
                .m {
                    img {
                        width: 80px;
                        height: 30px;
                    }
                    .daizhifu {
                        color: #EA5620;
                    }
                }
                .r {
                    .area {
                        color: #9A9A9A;
                    }
                }
            }
            .item-time {
                height: 80px;
                line-height: 80px;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
                span.time {
                    color: #343434;
                }
            }
            .item-operation {
                display: flex;
                justify-content: flex-end;
                align-items: center;
                height: 110px;
                padding: 0 20px;
                div {
                    width:130px;
                    height:45px;
                    line-height: 45px;
                    margin-left: 20px;
                    text-align: center;
                    color: #fff;
                }
                .pay {
                    background-color:#F6926E;
                    border:1px solid #EA5620;
                }
                .cancel {
                    color: #EA5620;
                    background-color:#FFFFFF;
                    border:1px solid #EA5620;
                }
                .edit {
                    background-color:#5296E5;
                    border:1px solid #00428E;
                }
            }
        }
    }
}
.van-popup {
    width: 480px;
    height: 180px;
    border-radius:8px;
    text-align: center;
    .content {
        padding: 40px;
        line-height: 1.6;
        .p1 {
            span {
                color: #EA5620;
            }
        }
    }
}
</style>