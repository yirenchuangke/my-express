<template>
    <div class="logisticsOrder-container">
        <CCII-Header>订单详情</CCII-Header>
        <div class="content">
            <div class="item">
                <div class="item-title">
                    <p class="c_666">运单号：<span class="c_333">DP20200506625010</span></p>
                </div>
                <div class="item-content">
                    <div class="l">
                        <p class="fs_30 fw_600">天津市</p>
                        <p class="area">天津中渔冷库</p>
                    </div>
                    <div class="m">
                        <img :src="require('assets/yongche1.png')" alt="">
                        <!-- <img :src="require('assets/yongche.png')" alt=""> -->
                        <p class="daizhifu fw_600">待支付</p>
                    </div>
                    <div class="r"> 
                        <p class="fs_30 fw_600">天津市</p>
                        <p class="area">天津中渔冷库</p>
                    </div>
                </div>
                <div class="item-tag c_999">
                    <span>整车</span>
                    <span>4.2米</span>
                    <span>自选路线/固定路线</span>
                </div>
                <div class="item-time">
                    <p class="fs_20 c_666">下单时间：<span class="c_333">2020-05-06  14:18</span></p>
                </div>
            </div>
            <div class="item">
                <div class="item-address">
                    <p class="fs_28 c_333">配送地址</p>
                </div>
                <div class="item-shipping">
                    <p class="c_666">发货地址：</p>
                    <div class="c_333">
                        <p class="tr ellipsis">北京市朝阳区CBD国际大北京大</p>
                        <p class="tr">张冉   136****6704</p>
                    </div>
                </div>
                <div class="item-shipping">
                    <p class="c_666">发货地址：</p>
                    <div class="c_333">
                        <p class="tr ellipsis">北京市朝阳区CBD国际大北京大</p>
                        <p class="tr">张冉   136****6704</p>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="item-info">
                    <p class="fs_28 c_333">货物信息</p>
                </div>
                <div class="item-detail c_666 clearfix">
                    <p><span class="">货物品类</span><span class="fr">猪</span></p>
                    <p><span class="">箱数（箱）</span><span class="fr">10</span></p>
                    <p><span class="">重量（kg）</span><span class="fr">12</span></p>
                    <p><span class="">体积（m³）</span><span class="fr">12</span></p>
                    <p><span class="">温度（℃）</span><span class="fr">13</span></p>
                    <p><span class="">是否装货</span><span class="fr">是</span></p>
                    <p><span class="">是否装货</span><span class="fr">是</span></p>
                    <p>
                        <span class="">补充说明：</span>
                        <span>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Tempore pariatur obcaecati sunt dolore magnam. Culpa, illum enim quaerat cupiditate minima libero quas temporibus dolore aliquam, necessitatibus vel laboriosam vero repellat!
                        </span>
                    </p>
                </div>
            </div>
        </div>
        <!-- 显隐 -->
        <div class="footer clearfix">
            <div class="fs_32 red">
                ¥1000
            </div>
            <div class="fs_32 blue">
                去支付
            </div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    },
    mounted() {

    },
    methods: {

    }
}
</script>

<style lang="scss" scoped>
.logisticsOrder-container {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .content {
        background-color: #F4F4F4;
        .item {
            margin: 15px 20px;
            background-color: #fff;
            border-radius: 8px;
            .item-title {
                height: 80px;
                line-height: 80px;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
                span {
                    color: #343434;
                }
            }
            .item-content {
                display: flex;
                justify-content: space-around;
                align-items: center;
                height: 110px;
                border-bottom: 1px solid #F4F4F4;
                .l {
                    .area {
                        color: #9A9A9A;
                    }
                }
                .m {
                    img {
                        width: 80px;
                        height: 30px;
                    }
                    .daizhifu {
                        color: #EA5620;
                    }
                }
                .r {
                    .area {
                        color: #9A9A9A;
                    }
                }
            }
            .item-tag {
                height: 80px;
                line-height: 80px;
                border-bottom: 1px solid #F4F4F4;
                padding: 0 20px;
                span {
                    margin-right: 10px;
                    padding: 5px 10px;
                    border: 1px solid #EEEEEE;
                    border-radius:8px;
                }
            }
            .item-time {
                height: 80px;
                line-height: 80px;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
            }
            .item-address {
                height: 80px;
                line-height: 80px;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
            }
            .item-shipping {
                height: 110px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
                div {
                    width: 500px;
                }
            }
            .item-info {
                height: 80px;
                line-height: 80px;
                padding: 0 20px;
                border-bottom: 1px solid #F4F4F4;
            }
            .item-detail {
                padding: 20px;
                margin-bottom: 100px;
                p {
                    padding: 10px 0;
                }
            }
        }
    }
    .footer {
        position: fixed;
        bottom: 0;
        left: 0;
        background-color: #fff;
        width: 100%;
        height: 98px;
        line-height: 98px;
        text-align: center;
        div {
            float: left;
            width: 50%;
        }
        .red {
            color: #FF0000;
        }
        .blue {
            background:linear-gradient(183deg,rgba(33,142,237,1),rgba(3,90,190,1));
            color: #fff;
        }
    }
}
</style>