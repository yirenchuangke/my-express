<template>
    <div class="data">
        <CCII-Header>数据统计</CCII-Header>
        <div class="data-container"></div>
        <div class="data-content">
            <div class="data-title">
                <p class="c_666 fs_32">国际贸易</p>
            </div>
            <div class="data-detail">
                <div class="total-price">
                    <p class="c_666">总订单金额</p>
                    <p class="fs_28 fw_600">$188，888，66</p>
                </div>
                <div class="total-price no-border">
                    <p class="c_666">订单数</p>
                    <p><span class="fs_28 fw_600">520</span>单</p>
                </div>
            </div>
            <div class="data-detail2">
                <div class="total-price">
                    <p class="c_666">在途货值</p>
                    <p class="price">$188，88</p>
                </div>
                <div class="total-price no-border">
                    <p class="c_666">待提货值</p>
                    <p class="blue">$520</p>
                </div>
            </div>
        </div>
        <div class="data-content mt">
            <div class="data-title">
                <p class="c_666 fs_32">在线商城（买家）</p>
            </div>
            <div class="data-detail">
                <div class="total-price">
                    <p class="c_666">采购金额</p>
                    <p class="fs_28 fw_600">$188，888，66</p>
                </div>
                <div class="total-price no-border">
                    <p class="c_666">订单数</p>
                    <p><span class="fs_28 fw_600">520</span>单</p>
                </div>
            </div>
            <div class="data-detail2">
                <div class="total-price">
                    <p class="c_666">待收货</p>
                    <p class="price">$188，88</p>
                </div>
                <div class="total-price no-border">
                    <p class="c_666">待发货</p>
                    <p class="blue">$520</p>
                </div>
            </div>
        </div>
        <div class="data-content mt">
            <div class="data-title">
                <p class="c_666 fs_32">在线商城(卖家）</p>
            </div>
            <div class="data-detail">
                <div class="total-price no-bottom-border">
                    <p class="c_666">销售金额</p>
                    <p class="fs_28 fw_600">$188，888，66</p>
                </div>
                <div class="total-price no-border no-bottom-border">
                    <p class="c_666">订单数</p>
                    <p><span class="fs_28 fw_600">520</span>单</p>
                </div>
            </div>
            <div class="contrast">
                <div><p class="p1 c_666">较上月  <span class="red fw_600">+100.00%</span></p></div>
                <div class="no-border"><p class="p1 c_666">较上月  <span class="red fw_600">+100.00%</span></p></div>
            </div>
            <div class="data-detail2">
                <div class="total-price">
                    <p class="c_666">待发货</p>
                    <p class="price">$188，88</p>
                </div>
                <div class="total-price">
                    <p class="c_666">待收货</p>
                    <p class="price">$188，88</p>
                </div>
                <div class="total-price no-border">
                    <p class="c_666">待支付</p>
                    <p class="blue">$520</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.data {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .data-container {
        height: 222px;
        background: url('../../assets/sjtj-bg.png') no-repeat;
        background-size: contain;
        background-color: #F4F4F4;
    }
    .data-content {
        margin: -15px 10px 15px;
        border-radius:8px;
        background-color: #fff;
        .data-title {
            height:80px;
            line-height: 80px;
            padding-left: 20px;
            border-bottom: 1px solid #F4F4F4;
        }
        .data-detail {
            display: flex;
            height: 132px;
            .total-price {
                flex: 1;
                padding: 35px 0 0 20px;
                border-bottom: 1px solid #F4F4F4;
                border-right: 1px solid #F4F4F4;
                p {
                    margin-bottom: 10px;
                    span {
                        color: #00428E;
                    }
                }
                p.fs_28 {
                    color: #EA5520;
                }
            }
            .no-border {
                border-right: none;
            }
            .no-bottom-border {
                border-bottom: none;;
            }
        }
        .data-detail2 {
            display: flex;
            height: 98px;
            .total-price {
                flex: 1;
                padding: 20px 0 0 20px;
                border-bottom: 1px solid #F4F4F4;
                border-right: 1px solid #F4F4F4;
                p {
                    margin-bottom: 10px;
                }
                p.price {
                    color: #EA5520;
                }
                p.blue {
                    color: #00428E;
                }
            }
            .no-border {
                border-right: none;
            }
        }
        .contrast {
            display: flex;
            border-bottom: 1px solid #F4F4F4;
            div {
                height: 64px;
                line-height: 64px;
                border-right: 1px solid #F4F4F4;
                flex: 1;
                p {
                    margin-left: 20px;
                    span.red {
                        color: #FF0000;
                    }
                }
                .p1 {
                    font-size: 20px;
                }

            }
            .no-border {
                border-right: none;
            }
        }
    }
    .mt {
        margin-top: 10px;
    }
}
</style>