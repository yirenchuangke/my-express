
<template>
    <div class="purchase-domestic">
        <van-sticky>
            <CCII-Header>销售订单（商城）</CCII-Header>
            <div class="date">
                <span class="orders">所有订单</span>
            </div>
            <div class="total">
                <div>
                    <p>订单金额</p>
                    <p><span class="fs_28 fw_600">1884.07</span>美元</p>
                </div>
                <div>
                    <p>订单数</p>
                    <p><span class="fs_28 fw_600">520</span>单</p>
                </div>
                <div class="noborder">
                    <p>待收货</p>
                    <p><span class="fs_28 fw_600">520</span>单</p>
                </div>
            </div>
        </van-sticky>
        <div class="order-list">
            <van-tabs v-model="active" sticky offset-top="151" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="全部">
                    <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        @load="onLoad"
                    >
                        <div class="list-item" v-for="item in list" :key="item">
                            <div class="item-title">
                                <p class="c_666">订单编号：201908152412</p>
                                <p class="status fw_600">待付款</p>
                            </div>
                            <div class="item-content">
                                <div class="item-l">
                                    <p class="fs_26 ellipsis p1">阿根廷进口京精品牛一把</p>
                                    <p class="fs_26 ellipsis p2">店铺：大连广龙店铺</p>
                                </div>
                                <div class="item-r">
                                    <p class="tr fw_600 p1">￥88,92</p>
                                    <p class="p2">2019-08-06 18:00</p>
                                </div>
                            </div>
                        </div>
                    </van-list>
                </van-tab>
                <van-tab title="待付款">内容 2</van-tab>
                <van-tab title="待发货">内容 3</van-tab>
                <van-tab title="待收货">内容 4</van-tab>
                <van-tab title="已完成">内容 5</van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {

    },
    methods: {
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.purchase-domestic {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .date {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        height: 80px;
        background-color: #FDA383;
        padding: 40px;
        .orders {
            color: #343434;
        }
    }
    .total {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        height: 134px;
        color: #fff;
        background:linear-gradient(180deg,rgba(253,163,131,1),rgba(234,84,32,1));
        padding: 0 20px;
        div {
            flex: 1;
            border-right: 1px solid #fff;
            margin-left: 20px;
        }
        .noborder {
            border: none;
        }
    }
    .order-list {
        background-color: #F4F4F4;
        .list-item {
            background-color: #fff;
            margin: 10px;
            .item-title {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 64px;
                border-bottom: 1px solid #F4F4F4;
                padding: 0 20px;
                .status {
                    color: #FF0000;
                }
            }
            .item-content {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 132px;
                padding: 0 20px;
                .item-l {
                    width: 450px;
                    p {
                        margin: 10px 0;
                    }
                    .p1 {
                        color: #343434;
                    }
                    .p2 {
                        color: #9A9A9A;
                    }
                }
                .item-r {
                    p {
                        margin: 10px 0;
                    }
                    .p1 {
                        color: #FF0000;
                    }
                    .p2 {
                        color: #9A9A9A;
                    }
                }
            }
        }
    }
}
</style>