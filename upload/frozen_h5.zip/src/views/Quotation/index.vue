<template>
    <div class="quotation">
        <CCII-Header>我的报价单</CCII-Header>
        <div class="quotation-tabs">
            <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="全部">
                    <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        @load="onLoad"
                    >
                        <div class="" v-for="item in list" :key="item">
                            <div class="categories-one clearfix">
                                <div class="cate-title">
                                    <p class="c_666">订单编号：201908152412</p>
                                </div>
                                <div class="cate-detail" @click="$router.push('/quotation/detail')">
                                    <img :src="require('assets/gqdt.png')" alt="">
                                    <div class="cate-name fs_26">
                                        <p class="ellipsis">阿根廷进口京精品牛一把</p>
                                        <p class="ellipsis">供货店铺：小星星</p>
                                        <p class="ellipsis">采购数量：1888899</p>
                                    </div>
                                    <div class="cate-price">
                                        <p class="price">￥1000</p>
                                        <p>我的报价</p>
                                    </div>
                                </div>
                                <div class="cate-total">
                                    <p class="fw_600">卖家报价：￥1200</p>
                                    <div class="operation">
                                        <span class="cancel">取消</span>
                                        <span class="info">去支付</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </van-list>
                </van-tab>
                <van-tab title="待报价">内容 2</van-tab>
                <van-tab title="待发货">内容 3</van-tab>
                <van-tab title="待收货">内容 4</van-tab>
                <van-tab title="已完成">内容 5</van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {

    },
    methods: {
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.quotation {
    width: 100%;
    height: 100%;
    background-color: #F4F4F4;
    .quotation-tabs {
        background-color: #F4F4F4;
        .categories-one {
            background-color: #fff;
            margin: 15px;
            .cate-title {
                height: 64px;
                line-height: 64px;
                padding: 0 20px;
                border-bottom: 1px solid #EEEEEE;
            }
            .cate-detail {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 132px;
                padding: 0 20px;
                border-bottom: 1px solid #EEEEEE;
                .cate-name {
                    width: 450px;
                }
                .cate-price {
                    .price {
                        color: #FF0000;
                    }
                }
            }
            .cate-total {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 64px;
                padding: 0 20px;
                p.fw_600 {
                    color: #FF0000;
                }
                .operation {
                    span {
                        margin: 0 5px;
                    }
                    .cancel {
                        padding: 0 8px;
                        color: #EA5620;
                        border:1px solid #EA5620;
                        border-radius:8px;
                    }
                    .info {
                        padding: 0 8px;
                        color: #00428E;
                        border:1px solid #00428E;
                        border-radius:8px;
                    }
                }
            }
        }
    }
}
</style>