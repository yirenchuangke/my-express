<template>
    <div class="international-order-detail">
        <CCII-Header>查看订单详情</CCII-Header>
        <div class="detail-content">
            <div class="detail-describe tc">
                <p class="p1 fs_26 fw_600">待支付定金</p>
                <p class="p2">需付款：<span class="fs_32 fw_600">￥5500.00</span></p>
                <p>请到中冷官方网站电脑端进行支付！</p>
            </div>
            <div class="detail-content-box1 categories-one clearfix">
                <div class="cate-title">
                    <p class="c_666">武汉鲜美达店铺</p>
                </div>
                <div class="cate-detail">
                    <img :src="require('assets/gqdt.png')" alt="">
                    <div class="cate-name">
                        <p class="fs_26 p1"><span class="product-name ellipsis">阿根廷进口京精品牛一把</span></p>
                        <p class="c_666 p2 ellipsis"><span class="ellipsis">采购数量：100</span><span class="product-price fr tr fs_28">￥5500.00</span></p>
                    </div>
                </div>
            </div>
            <div class="detail-content-box2">
                <div class="order fs_26">
                    <p class="c_666 sn">订单编号：<span>20190806123456</span></p>
                    <p class="c_666">下单时间：<span>2018-08-06 18:00</span></p>
                </div>
            </div>
            <div class="detail-content-box3 c_666">
                <p><span class="">卖家报价</span><span class="fr">￥888.66</span></p>
                <p><span class="">定金金额</span><span class="fr">￥100</span></p>
                <p><span class="">定金比例</span><span class="fr">30%</span></p>
                <p><span class="">实际装车</span><span class="fr">5000</span></p>
                <p><span class="">尾款金额</span><span class="fr">￥150</span></p>
            </div>
            <!-- <div class="cancel-order">
                <div class="confirm"><p class="fs_32">确认收货</p></div>
                <div class="cancel"><p class="fs_28">取消订单</p></div>
            </div> -->
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.international-order-detail {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .detail-content {
        width: 100%;
        height: 218px;
        background: url('../../assets/gjmydd-bg.png') no-repeat;
        background-size: contain;
        .detail-describe {
            height: 100%;
            padding: 32px 0 53px;
            color: #fff;
            .p1 {
                margin-bottom: 30px;
            }
            .p2 {
                margin-bottom: 16px;
            }
        }
        .detail-content-box1 {
            margin: 10px 10px 0;
            background-color: #fff;
            .cate-title {
                padding: 0 20px;
                height: 64px;
                line-height: 64px;
                border-bottom: 1px solid #F2F2F2;
            }
            .cate-detail {
                height: 132px;
                padding: 0 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid #F2F2F2;
                img {
                    width: 120px;
                    height: 110px;
                    margin-right: 10px;
                }
                .cate-name {
                    flex: 1;
                    .p1 {
                        .product-name {
                            display: inline-block;
                            width: 550px;
                            color: #343434;
                        }
                    }
                    .p2 {
                        span:nth-child(1) {
                            display: inline-block;
                            width: 400px;
                        }
                        .product-price {
                            color: #FF0000;
                        }
                    }
                }
            }
        }
        .detail-content-box2 {
            margin:0 10px;
            background-color: #fff;
            .order {
                height: 132px;
                line-height: 1.5;
                padding: 30px 20px;
                border-bottom: 1px solid #F2F2F2;
                p {
                    span {
                        color: #343434;
                    }
                }
            }
        }
        .detail-content-box3 {
            margin:10px 10px 0;
            padding: 10px 20px;
            background-color: #fff;
            p {
                margin: 10px 0;
            }
        }
        .cancel-order {
            position: fixed;
            bottom: 0;
            left: 0;
            text-align: center;
            background-color: #fff;
            width:100%;
            height:95px;
            line-height: 95px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            .confirm {
                height: 100%;
                width: 558px;
                background:linear-gradient(13deg,rgba(34,143,237,1),rgba(3,90,190,1));
                color: #fff;
            }
            .cancel {
                flex: 1;
                color:#EA5620;
            }
        }
    }
}
</style>