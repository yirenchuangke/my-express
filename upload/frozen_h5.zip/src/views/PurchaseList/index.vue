<template>
    <div class="purchaseList">
        <div class="purchaseList-header">
            <i class="iconfont icon-zuojiantou" @click="$router.back()"></i>
            <p class="fs_36">采购清单</p>
            <p class="fs_24">编辑</p>
        </div>
        <div class="content">
            <div class="content-name">
                <input type="radio">
                <p>供应商名称：哈迪达有限公司（DL0027）</p>
            </div>
            <div class="content-item">

            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {

        }
    }
}
</script>

<style lang="scss" scoped>
.purchaseList {
    height: 100%;
    width: 100%;
    background-color: #F2F1F1;
    .purchaseList-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 88px;
        background-color: #fff;
        padding: 0 20px;
        color: #333333;
        .icon-zuojiantou:before {
            font-size: 40px;
            font-weight: 600;
            color: #333333;
        }
    }
    .content {
        margin: 20px;
        background-color: #fff;
        .content-name {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            height: 64px;
            padding: 0 20px;
        }
    }
}
</style>