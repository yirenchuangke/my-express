<template>
    <div>
        海外厂商进入某个具体店铺页面
    </div>
</template>

<script>
export default {
    data() {
        return {
            
        }
    },
    mounted() {

    },
    methods: {

    }
}
</script>

<style lang="scss" scoped>

</style>