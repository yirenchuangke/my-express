<template>
    <div class="circle-container">
        <div class="circle-search">
            <van-search
                v-model="value"
                shape="round"
                background="#fff"
                placeholder="请输入关键字"
            />
        </div>
        <!-- <van-search v-model="value" placeholder="请输入搜索关键词" /> -->
        <!-- <van-search
            placeholder="输入公司或职位"
            show-action
            :background="backgroundColor"
            shape="round"
            >
            <div slot="action">搜索</div>
        </van-search> -->
        <!-- <CCII-Tabs
            :listArray="tabList"
            :current="current"
            @change="changeTab"
            ref="tab"
            >
        </CCII-Tabs> -->
        <div class="tab-content">
            <van-tabs v-model="active" sticky offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="综合">
                    <van-list
                        v-model="loading"
                        :finished="finished"
                        finished-text="没有更多了"
                        @load="onLoad"
                    >
                        <div class="circle-item" v-for="item in list" :key="item" @click="toDetail(item.id)">
                            <img :src="require('assets/gqdt.png')" alt="">
                            <div class="item-text">
                                <p class="p1 fs_28 ellipsis">国际贸易小课堂—确定客户机合开启合开启合开启</p>
                                <p class="p2">3小时前<img :src="require('assets/dalaoshuo.png')" alt=""></p>
                                <p class="p3 ellipsis2">国际贸易小课堂—确定客户机合开启国际贸易小课堂—确定客户机合开启国际贸易小课堂—确定客户机合开启</p>
                            </div>
                        </div>
                    </van-list>
                </van-tab>
                <van-tab title="行业资讯">内容 2</van-tab>
                <van-tab title="冻品课堂">内容 3</van-tab>
                <van-tab title="中冷动态">内容 4</van-tab>
            </van-tabs>
            <!-- <van-list
                v-model="loading"
                :finished="finished"
                finished-text="没有更多了"
                @load="onLoad"
            > -->
                <!-- <van-cell v-for="item in list" :key="item" :title="item">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio exercitationem cumque nesciunt tempora quia cum reprehenderit eos doloribus, quam maxime eaque, maiores est a, ullam debitis aliquam veniam repellat id?
                </van-cell> -->
                <!-- <ul>
                    <li v-for="item in list" :key="item">{{item}}</li>
                </ul> -->
                <!-- <div class="content-box" v-for="item in list" :key="item">
                    {{item}}
                </div>
            </van-list> -->
        </div>
    </div>
</template>

<script>
// import Tabs from 'components/Tabs'
export default {
    // components: {
    //     'CCII-Tabs': Tabs
    // },
    data() {
        return {
            value: '',
            active: 0,
            // tabList: [
            //     { id: 1, name: "全部" },
            //     { id: 2, name: "", },
            //     { id: 3, name: "" },
            //     { id: 4, name: "冻品批发市场指南" },
            //     { id: 5, name: "行业资讯" },
            //     { id: 6, name: "冻品课堂" },
            //     { id: 7, name: "中冷动态" },
            // ],
            // current: 1,
            list: [],
            loading: false,
            finished: false,
        }
    },
    created() {

    },
    methods: {
        toDetail(id) {
            this.$router.push({path:'/circle/detail',query:{id}})
        },
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                this.finished = true;
                }
            }, 1000);
        },
        // 暂时不用
    // changeTab(index, e) {
    //     console.log(index);
        
    //   this.current = index;   // 高亮当前
    //   let tab = this.$refs.tab.$refs.headertab; // 包裹 ul的 div
    //   let tabitem = this.$refs.tab.$refs.tabitem;    // 包裹 li的 ul
    //   let winWidth = window.innerWidth;  // 当前屏幕的宽度
    //   let liList = e.target;   // 当前点击的li
    //   if (liList) {  //  当前li左偏移, li的宽度, 中间值(当前屏幕的宽度 - li的宽度) /2, 目标值 (中间值 - 当前li左偏移), 整个ul的宽度
    //     let liLeft = liList.offsetLeft,
    //       liWidth = liList.offsetWidth,
    //       liCenter = (winWidth - liWidth) / 2,
    //       liTarget = liLeft - liCenter;
    //     let ulWidth = tabitem.offsetWidth;
    //     if (liTarget < 0) {
    //       tab.scrollLeft = 0;
    //       return;
    //     }
    //     // winWidth(375) - ulWidth(436) =  -61
    //     if (liTarget < winWidth - ulWidth) {
    //       tab.scrollLeft = -(winWidth - ulWidth) + liWidth;
    //       return;
    //     }
    //     tab.scrollLeft = liTarget;
    //   }
    // },
  },
}
</script>

<style lang="scss" scoped>
.circle-container {
    background-color: #F2F1F1;
    height: 100%;
    .circle-search {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999;
        width: 100%;
        height: 88px;
        line-height: 88px;
        .van-search {
            height: 88px;
        }
    }
    .tab-content {
        padding: 88px 0 110px;
        background-color: #F2F1F1;
        .circle-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #fff;
            margin: 10px;
            height: 180px;
            border-radius:8px;
            padding: 10px;
            img {
                height: 120px;
                width: 210px;
                margin-right: 10px;
            }
            .item-text {
                width: 480px;
                .p1 {
                    color: #343434;
                }
                .p2 {
                    font-size: 20px;
                    color: #9A9A9A;
                    img {
                        width: 110px;
                        height: 41px;
                        vertical-align: bottom;
                        margin-left: 10px;
                    }
                }
                .p3 {
                    color: #9A9A9A;
                }
            }
        }
    }
}
</style>