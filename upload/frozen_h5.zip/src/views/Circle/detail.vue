<template>
    <div class="circle-detail">
        <CCII-Header>文章详情</CCII-Header>
        <div class="detail">
            <div class="text" v-html="ddd"></div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            ddd: '22222'
        }
    }
}
</script>

<style lang="scss" scoped>
.circle-detail {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .detail {
        background-color: #F4F4F4;
        padding: 10px;
        .text {
            padding: 10px;
            background-color: #fff;
            border-radius: 8px;
        }
    }
}
</style>