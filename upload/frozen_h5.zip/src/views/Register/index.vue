<template>
  <div id="login">
    <div id="back">
      <i class="iconfont icon-back" @click="$router.back()"></i>
      <!-- <img :src="require('assets/anai.png')" alt @click="$router.back()" /> -->
    </div>
    <div class="inner-box">
      <div class="inner-logo">
        <div class="inner-bg">
          <img :src="require('assets/login-logo.png')" alt />
        </div>
      </div>
      <div class="inner-title">
        <p>欢迎用户注册</p>
      </div>
      <div class="inner-form">
        <div id="username-box">
          <input type="text" placeholder="请输入账户名称" />
          <i class="iconfont icon-yonghu"></i>
        </div>
        <div id="mobile-box">
          <input type="text" maxlength="11" placeholder="请输入手机号码" />
          <img :src="require('assets/mobile.png')" alt />
        </div>
        <div id="yanzhengma-box">
          <input type="text" placeholder="请输入验证码" />
          <img :src="require('assets/yanzhengma.png')" alt />
          <div class="code" v-html="codetxt" @click="codetxt=='获取验证码'&&getCode()"></div>
        </div>
        <div id="pwd-box">
          <input id="pwd" type="password" placeholder="请输入密码" />
          <i class="iconfont icon-mima"></i>
          <p class="pwdTips">6-20位字母数字或字符</p>
        </div>
        <div id="pwd-box2">
          <input id="pwd2" type="password" placeholder="请再次输入密码" />
          <i class="iconfont icon-mima"></i>
        </div>
        <div id="zhizhao-box">
          <input id type="text" readonly placeholder="上传营业执照" />
          <img :src="require('assets/yingyezhizhao.png')" alt />
          <div class="code" @click="handleUpload">上传</div>
        </div>
        <!-- <van-uploader v-show="false" :before-read="beforeRead" :after-read="afterRead" :max-size="3 * 1024 * 1024">
        </van-uploader> -->
        <!-- <Upload v-show="true" ref="upload" @change="change" /> -->
        <div id="service-terms" class="clearfix">
          <div>
            <van-checkbox icon-size="15px" v-model="checked" shape="square" class="fl"></van-checkbox>
          </div>
          <div class="terms">
            <p>我已经阅读并同意《中冷冻品产业综合服务平台注册协议》，《中冷冻品隐私政策》。</p>
          </div>
        </div>
        <div id="register">
          <button @click="handleToRegister">注册</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Upload from "@/components/Upload";
export default {
  components: {
    Upload
  },
  data() {
    return {
      codetxt: "获取验证码",
      checked: false,
      timer: null,
      seconds: 60,
      //   showPwd: true,
      //   username: '',
      //   pwd: ''
    };
  },
  mounted() {

  },
  methods: {
    // beforeRead(file) {
    //   if (file.type !== "image/jpeg") {
    //     Toast("请上传 jpg 格式图片");
    //     return false;
    //   }
    //   return true;
    // },
    // afterRead(file) {
    //   // 此时可以自行将文件上传至服务器
    //   console.log(file);
    // },
    change(fd) {
      console.log(fd);
    },
    handleUpload() {
        this.$refs.upload.show();
    },
    handleToRegister() {
        
    },
    getCode() {
        let n = 60
        this.timer = setInterval(() => {
            this.codetxt =  `${n--}s`
            if (n == 0) {
                this.codetxt = "获取验证码"
                clearInterval(this.timer)
            }
        }, 1000)
    }
  },
  beforeDestroy() {
      clearInterval(this.timer)
      this.timer = null
  }
};
</script>

<style lang="scss" scoped>
input::-webkit-input-placeholder {
  color: #fff;
}
#login {
  font-size: 24px;
  width: 100%;
  height: 100%;
  background: url("../../assets/bg.png") no-repeat;
  background-size: 100% 100%;
  padding: 290px 70px 0;
  #back {
    position: fixed;
    left: 33px;
    top: 40px;
    .icon-back:before {
      font-size: 40px;
      color: #fff;
    }
    // img {
    //   width: 18px;
    //   height: 34px;
    // }
  }
  .inner-box {
    position: relative;
    height: 978px;
    width: 610px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 16px;
    padding: 149px 22px 20px;
    .inner-logo {
      position: absolute;
      top: -100px;
      left: 218px;
      width: 174px;
      height: 174px;
      background: rgba(242, 241, 241, 0.4);
      border-radius: 50%;
      padding: 11px;
      .inner-bg {
        background: url("../../assets/circle.png") no-repeat 100%;
        width: 152px;
        height: 152px;
        border-radius: 50%;
        padding: 16px;
        img {
          width: 120px;
          height: 120px;
        }
      }
    }
    .inner-title {
      position: absolute;
      top: 87px;
      left: 210px;
      p {
        text-align: center;
        color: #fff;
        font-size: 32px;
      }
    }
    .inner-form {
      border-top: 1px solid #88c5f3;
      input {
        width: 564px;
        height: 88px;
        border-bottom: 1px solid #88c5f3;
        background: #e1838300;
        color: #fff;
        padding: 0 84px 0;
      }
      #username-box {
        position: relative;
        .icon-yonghu:before {
          position: absolute;
          top: 22px;
          left: 18px;
          font-size: 34px;
          color: #fff;
        }
      }
      #mobile-box {
        position: relative;
        img {
          position: absolute;
          top: 30px;
          left: 35px;
          width: 26px;
          height: 29px;
        }
      }
      #yanzhengma-box {
        position: relative;
        img {
          position: absolute;
          top: 30px;
          left: 35px;
          width: 26px;
          height: 29px;
        }
        .code {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 180px;
          height: 64px;
          line-height: 64px;
          text-align: center;
          background-color: #90c0ee;
          color: #fff;
          border-radius: 0px 32px 32px 0px;
        }
      }
      #pwd-box {
        position: relative;
        .icon-mima:before {
          position: absolute;
          top: 30px;
          left: 34px;
          font-size: 26px;
          color: #fff;
        }
        .pwdTips {
          position: absolute;
          top: 95px;
          left: 83px;
          color: #dddddd;
        }
      }
      #pwd-box2 {
        position: relative;
        margin-top: 40px;
        .icon-mima:before {
          position: absolute;
          top: 30px;
          left: 34px;
          font-size: 26px;
          color: #fff;
        }
      }
      #zhizhao-box {
        position: relative;
        img {
          position: absolute;
          top: 30px;
          left: 35px;
          width: 26px;
          height: 29px;
        }
        .code {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 180px;
          height: 64px;
          line-height: 64px;
          text-align: center;
          background-color: #90c0ee;
          color: #fff;
          border-radius: 0px 32px 32px 0px;
        }
      }
      #service-terms {
        margin-top: 5px;
        padding: 0 20px 0 32px;
        color: #fff;
        .terms {
          margin-left: 40px;
        }
      }
      #register {
        padding: 0 40px;
        margin-top: 48px;
        button {
          width: 480px;
          height: 88px;
          padding: 0 40px;
          background-color: #dddddd;
          // background: linear-gradient(
          //   -13deg,
          //   rgba(3, 90, 190, 1),
          //   rgba(33, 142, 237, 1)
          // );
          border-radius: 44px;
          color: #fff;
          font-size: 40px;
        }
      }
    }
  }
}
</style>