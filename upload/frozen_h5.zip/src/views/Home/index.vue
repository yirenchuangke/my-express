<template>
  <div class="home-container">
    <div v-if="!$store.state.hasPermission" class="common-top-bar home-header">
      <img :src="require('assets/home-newlogo.png')" alt="logo" />
      <van-button round size="mini" type="default" @click="$router.push('./login')">登录</van-button>
    </div>
    <div v-else class="common-top-bar home-header">
      <img class="saoyisao" :src="require('assets/saoyisao.png')" alt="logo" />
      <img
        class="saoyisao"
        :src="require('assets/xiaoxi.png')"
        alt="logo"
        @click="$router.push('/inquiry')"
      />
    </div>
    <div
      ref="homebody"
      :class="!$store.state.hasPermission===true?'home-body bg':'home-body login-bg'"
    >
      <div class="home-banner" v-if="$store.state.hasPermission">
        <div class="company-name">
          <div class="company-name-bar">
            <img class="fl" :src="require('assets/gqdt.png')" alt="logo" />
            <p class="fl ellipsis">欢迎您，{{$store.state.userInfo.name}}</p>
          </div>
        </div>
        <div class="company-notice">
          <van-notice-bar left-icon="volume-o" text="在代码阅读过程中人们说脏话的频率是衡量代码质量的唯一标准。" />
          <!-- <van-notice-bar left-icon="volume-o" :scrollable="false">
            <van-swipe vertical class="notice-swipe" :autoplay="3000" :show-indicators="false">
              <van-swipe-item>2020年5月8号；编号2018542加拿大进口北极贝刺身 500g</van-swipe-item>
              <van-swipe-item>内容 2</van-swipe-item>
              <van-swipe-item>内容 3</van-swipe-item>
            </van-swipe>
          </van-notice-bar>-->
        </div>
        <div class="company-service">
          <div class="item" @click="$router.push('/dataStatistics')">
            <img :src="require('assets/home-small-bg.png')" alt="logo" />
            <img class="abs" :src="require('assets/home-sjtj.png')" alt="logo" />
            <p>数据统计</p>
          </div>
          <div class="item" @click="$router.push('/salesOrder')">
            <img :src="require('assets/home-small-bg.png')" alt="logo" />
            <img class="abs" :src="require('assets/home-xsdd.png')" alt="logo" />
            <p>销售订单</p>
          </div>
          <div class="item" @click="$router.push('/purchaseOrder/domesticOrders')">
            <img :src="require('assets/home-small-bg.png')" alt="logo" />
            <img class="abs" :src="require('assets/home-cgdd.png')" alt="logo" />
            <p>采购订单</p>
          </div>
          <div class="item" @click="$router.push('/inventoryQuery/domestic')">
            <img :src="require('assets/home-small-bg.png')" alt="logo" />
            <img class="abs" :src="require('assets/home-kccx.png')" alt="logo" />
            <p>库存查询</p>
          </div>
        </div>
      </div>
      <div class="home-banner" v-else>
        <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white" @click="dddd">
          <van-swipe-item>
            <img src="./test.png" alt />
          </van-swipe-item>
          <van-swipe-item>
            <img src="./test.png" alt />
          </van-swipe-item>
        </van-swipe>
      </div>
      <div class="home-services">
        <p class="fs_32 c_333 fw_600">推荐服务</p>
        <div class="services-out-box">
          <div class="services-content" @click="$router.push('/shopList?index=0')">
            <img :src="require('assets/qqdpbk.png')" alt />
            <p>全球商品百科</p>
          </div>
          <div class="services-content" @click="$router.push('/coldStorage')">
            <img :src="require('assets/llccfw.png')" alt />
            <p>冷链仓储服务</p>
          </div>
          <div class="services-content" @click="$router.push('/useCar')">
            <img :src="require('assets/llwlfw.png')" alt />
            <p>冷链物流服务</p>
          </div>
        </div>
      </div>
      <div class="home-index">
        <div class="index-title clearfix">
          <span class="c_333 fs_32 fw_600 fl">中冷指数</span>
          <span class="fl fs_20 c_666">(2020年4月-6月)</span>
          <span class="fr more">
            更多<i class="iconfont icon-jiantou"></i>
          </span>
        </div>
        <div id="myChart"></div>
      </div>
      <div class="home-frozen">
        <div class="clearfix">
          <span class="c_333 fs_32 fw_600 fl">冻品头条</span>
          <span class="fr more" @click="$router.push('/circle')">
            更多<i class="iconfont icon-jiantou"></i>
          </span>
        </div>
      </div>
      <div class="frozen-content clearfix" @click="$router.push('/circle/detail')">
        <img :src="require('assets/gqdt.png')" alt />
        <div class="content-text">
          <p class="fs_28 c_333 fw_600 ellipsis">国际贸易小课堂—确定客户机合国际贸易小课堂—确定客户机合</p>
          <p class="fs_20 c_999">3小时前</p>
          <p class="fs_24 c_999 ellipsis2">开启国际贸易委托代理进口业务流程的第一步便是确定客户及合作方式。在此在此在此</p>
        </div>
      </div>
      <div class="frozen-content clearfix">
        <img :src="require('assets/gqdt.png')" alt />
        <div class="content-text">
          <p class="fs_28 c_333 fw_600 ellipsis">国际贸易小课堂—确定客户机合国际贸易小课堂—确定客户机合</p>
          <p class="fs_20 c_999">3小时前</p>
          <p class="fs_24 c_999 ellipsis2">开启国际贸易委托代理进口业务流程的第一步便是确定客户及合作方式。在此在此在此</p>
        </div>
      </div>
      <div class="frozen-content clearfix">
        <img :src="require('assets/gqdt.png')" alt />
        <div class="content-text">
          <p class="fs_28 c_333 fw_600 ellipsis">国际贸易小课堂—确定客户机合国际贸易小课堂—确定客户机合</p>
          <p class="fs_20 c_999">3小时前</p>
          <p class="fs_24 c_999 ellipsis2">开启国际贸易委托代理进口业务流程的第一步便是确定客户及合作方式。在此在此在此</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      option: {
        legend: {
          data: ["肉类指数", "水产指数"]
        },
        xAxis: {
          type: "category", // 还有其他的type，可以去官网喵两眼哦
          data: [0,5,10,15,20,25,30], // x轴数据
        //   name: "日期", // x轴名称
          // x轴名称样式
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        },
        yAxis: {
          type: "value",
        //   name: "纵轴名称", // y轴名称
          // y轴名称样式
          nameTextStyle: {
            fontWeight: 600,
            fontSize: 18
          }
        },
        label: {},
        tooltip: { trigger: "axis" },
        series: [
          {
            name: "肉类指数",
            data: [820, 932, 901, 934, 1290, 1330, 1320],
            type: "line"
          },
          {
            name: "水产指数",
            data: [620, 711, 823, 934, 1445, 1456, 1178],
            type: "line"
          }
        ]
      }
    };
  },
  mounted() {
    console.log("我执行了");
    let myChart = this.$echarts.init(document.getElementById("myChart"));
    myChart.setOption(this.option);
    // let timer
    // window.addEventListener("scroll", () => {
    //     let scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
    //     if (timer) clearTimeout(timer)
    //     timer = setTimeout(() => {
    //         sessionStorage.setItem('home-position',scrollTop)
    //     },50)
    // });
  },
  //   activated() {
  //       window.pageYOffset=sessionStorage.getItem('home-position') || 0
  //   },
  methods: {
    dddd() {
      console.log(111);
    }
  }
};
</script>

<style lang="scss" scoped>
$home-width: 690px;
$home-title: 32px;
$home-title-color: #333;
.more {
  color: #656565 !important;
  font-size: 24px;
  font-weight: 400 !important;
}
.home-container {
  height: 100%;
  .home-header {
    background-color: #fff;
    box-shadow: 4px 0px 2px 0px #d8d2d2;
    padding: 10px 31px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    img {
      width: 181px;
      height: 56px;
    }
    .saoyisao {
      width: 35px;
      height: 35px;
    }
    .van-button--round {
      width: 96px;
      height: 56px;
      color: #00428e;
      font-size: 24px;
      border-color: #035abe;
    }
  }
  .home-body {
    margin: 88px 0 115px;
    padding: 24px 30px;
    .home-banner {
      height: 340px;
      width: $home-width;
      border-radius: 8px;
      background-color: #ffffff;
      img {
        height: 100%;
        width: 100%;
      }
      .custom-indicator {
        color: #fff;
        font-size: 20px;
        line-height: 150px;
        text-align: center;
        background-color: #39a9ed;
      }
      .company-name {
        height: 106px;
        line-height: 106px;
        width: 100%;
        padding: 0 20px;
        font-size: $home-title;
        color: $home-title-color;
        .company-name-bar {
          height: 100%;
          border-bottom: 1px solid #eeeeee;
          img {
            height: 74px;
            width: 74px;
            margin: 20px 20px 0 0;
          }
          p {
            width: 520px;
          }
        }
      }
      .company-notice {
        margin-top: 16px;
        .van-notice-bar {
          background: #fff;
          //   .van-icon-volume-o::before {
          //     content: "通知";
          //     color: #ccc;
          // }
          .notice-swipe {
            font-size: 20px;
            color: #333;
            height: 40px;
            line-height: 40px;
          }
        }
      }
      .company-service {
        display: flex;
        justify-content: space-around;
        margin-top: 35px;
        .item {
          position: relative;
          height: 120px;
          width: 100px;
          img {
            height: 80px;
            width: 80px;
            margin: 0 8px;
          }
          .abs {
            position: absolute;
            top: 17px;
            left: 17px;
            width: 46px;
            height: 46px;
          }
          p {
            color: #343434;
            font-weight: 600;
            text-align: center;
          }
        }
      }
    }
    .home-services {
      margin-top: 24px;
      height: 286px;
      border-radius: 8px;
      border: 1px solid rgba(255, 255, 255, 1);
      background: rgba(255, 255, 255, 1);
      box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.05);
      padding: 20px 15px;
      .services-out-box {
        display: flex;
        justify-content: space-around;
        align-items: center;
        .services-content {
          margin-top: 20px;
          width: 210px;
          height: 120px;
          img {
            height: 100%;
            width: 100%;
            margin-bottom: 10px;
          }
          p {
            color: #656565;
            font-size: 28px;
            text-align: center;
          }
        }
      }
    }
    .home-index {
      margin: 24px 0;
      padding: 20px 15px;
      width: $home-width;
      height: 362px;
      background: rgba(255, 255, 255, 1);
      border: 1px solid rgba(255, 255, 255, 1);
      box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.05);
      border-radius: 8px;
      #myChart {
        height: 300px;
        width: 100%;
      }
    }
    .home-frozen {
      padding: 20px 15px;
      width: $home-width;
      height: 80px;
      background: rgba(255, 255, 255, 1);
      box-shadow: -1px -1px 3px 0px rgba(0, 0, 0, 0.05);
      border-radius: 8px 8px 0 0;
    }
    .frozen-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 156px;
      padding: 0 10px;
      box-shadow: 0px 4px 8px 0px rgba(0, 0, 0, 0.05);
      border-radius: 0 0 8px 8px;
      img {
        width: 210px;
        height: 120px;
        margin-right: 10px;
      }
      .content-text {
        flex: 1;
        width: 380px;
        font-size: 32px;
        line-height: 1.2;
      }
    }
  }
  .home-body.bg {
    background: url("../../assets/tuoyuan.png") no-repeat;
    background-size: contain;
  }
  .home-body.login-bg {
    background: url("../../assets/home-login-bg.png") no-repeat;
    background-size: contain;
  }
}
</style>