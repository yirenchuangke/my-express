<template>
    <div class="international-trade-order">
        <CCII-Header>国际贸易订单</CCII-Header>
        <div class="order-categories">
            <van-tabs v-model="active" sticky :ellipsis="false" offset-top="44" swipeable animated color="#00428E" title-inactive-color="#666666" title-active-color="#00428E" :swipe-threshold="6">
                <van-tab title="全部">
                    <div class="tab-content">
                        <van-list
                            v-model="loading"
                            :finished="finished"
                            finished-text="没有更多了"
                            @load="onLoad"
                        >
                            <div class="content-box" v-for="item in list" :key="item">
                                <!-- <div class="categories-one">

                                </div> -->
                                <div class="categories-one clearfix" @click="$router.push('/internationalTradeOrder/detail')">
                                    <div class="cate-title">
                                        <p class="c_666">订单编号：201908152412</p><span class="fw_600">待审核</span>
                                    </div>
                                    <div class="cate-detail">
                                        <img :src="require('assets/gqdt.png')" alt="">
                                        <div class="cate-name fs_26">
                                            <p class="ellipsis">阿根廷进口京精品牛一把</p>
                                            <p>厂号：bl55205</p>
                                        </div>
                                        <div class="tr">
                                            <p>1000吨</p>
                                            <p class="c_999">2019-08-06 18:00</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </van-list>
                    </div>
                </van-tab>
                <van-tab title="待付款">
                    2
                </van-tab>
                <van-tab title="待发货">内容 3</van-tab>
                <van-tab title="待报关清关">内容 4</van-tab>
                <van-tab title="待入库">内容 5</van-tab>
                <van-tab title="已完成">内容 6</van-tab>
            </van-tabs>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {
            active: 0,
            list: [],
            loading: false,
            finished: false,
        }
    },
    mounted() {
        this.active = this.$route.query.index || 0
    },
    methods: {
        onLoad() {
            // 异步更新数据
            // setTimeout 仅做示例，真实场景中一般为 ajax 请求
            setTimeout(() => {
                for (let i = 0; i < 10; i++) {
                    this.list.push(this.list.length + 1);
                }

                // 加载状态结束
                this.loading = false;

                // 数据全部加载完成
                if (this.list.length >= 40) {
                    this.finished = true;
                }
            }, 1000);
        },
    }
}
</script>

<style lang="scss" scoped>
.international-trade-order {
    height: 100%;
    width: 100%;
    background-color: #F4F4F4;
    .order-categories {
        background-color: #F4F4F4;
        .categories-one {
            height: 196px;
            background:#fff;
            margin: 10px;
            .cate-title {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 64px;
                border-bottom: 1px solid #F4F4F4;
                padding: 0 20px;
                span {
                    color: #FF0000;
                }
            }
            .cate-detail {
                display: flex;
                justify-content: space-between;
                align-items: center;
                height: 132px;
                padding: 11px 20px;
                img {
                    height: 110px;
                    width: 120px;
                    margin-right: 20px;
                }
                div.cate-name {
                    p {
                        width: 340px;
                    }
                }
                div {
                    p {
                        margin: 10px 0;
                    }
                }
            }
        }
    }
}
</style>