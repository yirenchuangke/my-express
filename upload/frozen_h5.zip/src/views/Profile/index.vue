<template>
    <div class="profile">
        <div class="profile-header">
            <div class="header-avatar">
                <img :src="require('assets/man-avatar.png')" alt="">
            </div>
            <p v-if="!$store.state.hasPermission" class="login-register">
                <router-link tag="span" to="/login">登录</router-link>/<router-link tag="span" to="/register">注册</router-link>
            </p>
            <p v-else class="login-register">{{$store.state.userInfo.name}}</p>
            <div class="login-detail">
                <p @click="$router.push('./businessCard')">企业名片<i class="iconfont icon-xiajiantou1"></i></p>
                <p @click="$router.push('./information')">编辑资料<i class="iconfont icon-xiajiantou1"></i></p>
            </div>
        </div>
        <div class="profile-function">
            <div><p class="count rel">10<span class="abs">+5</span></p><p class="text">商品收藏</p></div>
            <!-- <div><p class="count rel">10<span class="abs">+5</span></p><p class="text">到货通知</p></div> -->
            <!-- <div><p class="count rel">10</p><p class="text">商品评论</p></div> -->
            <!-- <div><p class="count rel">10</p><p class="text">商品咨询</p></div> -->
            <div><p class="count rel">10<span class="abs">+5</span></p><p class="text">店铺收藏</p></div>
        </div>
        <div class="profile-content">
            <div class="international-trade-order-service">
                <div class="service-name">
                    <p>国际贸易订单服务</p>
                    <router-link tag="p" to='/internationalTradeOrder'><p class="more">查看更多<i class="iconfont icon-jiantou"></i></p></router-link>
                </div>
                <div class="service-group">
                    <div class="service-item rel" @click="toInternationalOrder(1)">
                        <img :src="require('assets/daifukuan.png')" alt="">
                        <span class="abs">2</span>
                        <p>待付款</p>
                    </div>
                    <div class="service-item rel" @click="toInternationalOrder(2)">
                        <img :src="require('assets/fahuoxinxi.png')" alt="">
                        <p>待发货</p>
                    </div>
                    <div class="service-item rel" @click="toInternationalOrder(3)">
                        <img :src="require('assets/fahuoxinxi.png')" alt="">
                        <p>待报关清关</p>
                    </div>
                    <div class="service-item rel" @click="toInternationalOrder(4)">
                        <img :src="require('assets/tihuozhong.png')" alt="">
                        <p>待入库</p>
                    </div>
                </div>
            </div>
            <div class="international-trade-order-service">
                <div class="service-name">
                    <p>商城订单</p>
                    <router-link tag="p" to='/mallOrder'><p class="more">查看更多<i class="iconfont icon-jiantou"></i></p></router-link>
                </div>
                <div class="service-group">
                    <div class="service-item rel" @click="toMallOrder(1)">
                        <img :src="require('assets/daifukuan1.png')" alt="">
                        <span class="abs">2</span>
                        <p>待付款</p>
                    </div>
                    <div class="service-item rel" @click="toMallOrder(2)">
                        <img :src="require('assets/daifahuo.png')" alt="">
                        <p>待发货</p>
                    </div>
                    <div class="service-item rel" @click="toMallOrder(3)">
                        <img :src="require('assets/daishouhuo.png')" alt="">
                        <p>待收货</p>
                    </div>
                    <div class="service-item rel" @click="$router.push('/quotation')">
                        <img :src="require('assets/baojiadan.png')" alt="">
                        <p>报价单</p>
                    </div>
                </div>
            </div>
            <div class="international-trade-order-service">
                <div class="service-name">
                    <p>物流订单</p>
                    <router-link tag="p" to='/logisticsOrder'><p class="more">查看更多<i class="iconfont icon-jiantou"></i></p></router-link>
                </div>
                <div class="service-group">
                    <div class="service-item rel" @click="toLogisticsOrder(0)">
                        <img :src="require('assets/daiqueren.png')" alt="">
                        <span class="abs">2</span>
                        <p>待确认</p>
                    </div>
                    <div class="service-item rel" @click="toLogisticsOrder(1)">
                        <img :src="require('assets/yunshuzhong.png')" alt="">
                        <p>运输中</p>
                    </div>
                    <div class="service-item rel" @click="toLogisticsOrder(2)">
                        <img :src="require('assets/yiwancheng.png')" alt="">
                        <p>已完成</p>
                    </div>
                    <!-- <div class="service-item rel">
                        <img :src="require('assets/pingjia.png')" alt="">
                        <p>评价</p>
                    </div> -->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            
        }
    },
    mounted() {
        
    },
    methods: {
        // 商城订单
        toMallOrder(index) {
            this.$router.push({path:'/mallOrder', query:{index}})
        },
        // 国际贸易订单
        toInternationalOrder(index) {
            this.$router.push({path:'/internationalTradeOrder', query:{index}})
        },
        // 物流订单
        toLogisticsOrder(index) {
            this.$router.push({path:'/logisticsOrder', query:{index}})
        }
    }
}
</script>

<style lang="scss" scoped>
.profile {
    height: 100%;
    width: 100%;
    background: url('../../assets/profile-bg.png') no-repeat;
    background-size: contain;
    background-color: #F2F1F1;
    .profile-header {
        width: 100%;
        height: 403px;
        padding: 87px 200px 0;
        .header-avatar {
            width:134px;
            height:134px;
            background:rgba(255,255,255,1);
            opacity:0.92;
            border-radius:50%;
            padding: 6px;
            margin: 0 auto 16px;
            img {
                width: 122px;
                height: 122px;
            }
        }
        .login-register {
            text-align: center;
            font-size: 32px;
            color: #ffffff;
            margin-bottom: 48px;
        }
        .login-detail {
            display: flex;
            justify-content: space-around;
            color:#666666;
            font-size: 24px;
            p {
                display: flex;
                align-items: center;
                padding: 15px 16px;
                width:160px;
                height:54px;
                background:rgba(255,255,255,.6);
                border-radius:27px;
            }
        }
    }
    .profile-function {
        width: 730px;
        height: 98px;
        background-color: #fff;
        border-radius:8px;
        margin: 0 10px 17px;
        display: flex;
        justify-content: space-around;
        align-items: center;
        div {
            color: #666666;
            .count {
                font-size: 28px;    
                text-align: center;  
                font-weight: 600;          
            }
            .rel {
                position: relative;
                .abs {
                    position: absolute;
                    top: -8px;
                    color: #EA5520;
                    font-size: 20px;
                }
            }
            .text {
                font-size: 24px;                
            }
        }
    }
    .profile-content {
        padding: 0 0 115px;
        background-color: #F2F1F1;
        .international-trade-order-service {
            margin: 10px;
            background-color: #fff;
            height: 220px;
            border-radius: 8px;
            .service-name {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 24px;
                font-size: 32px;
                color: #333333;
                font-weight: 600;
                height: 80px;
                border-bottom: 1px solid #efefef;
                .more {
                    color: #999999;
                    font-size: 24px;
                }
            }
            .service-group {
                display: flex;
                padding: 24px 45px 0;
                .service-item {
                    height: 120px;
                    width: 120px;
                    img {
                        height: 45px;
                        width: 45px;
                        margin: 0 40px 10px;
                    }
                    p {
                        font-size: 24px;
                        color: #333333;
                        text-align: center;
                    }
                }
                .rel {
                    position: relative;
                    .abs {
                        position: absolute;
                        top: -12px;
                        right: 10px;
                        width:34px;
                        height:34px;
                        background:linear-gradient(-13deg,rgba(247,152,152,1),rgba(243,64,64,1));
                        border-radius:50%;
                        color: #FFFFFF;
                        text-align: center;
                        font-size: 20px;
                    }
                }
            }
        }
    }
}
</style>