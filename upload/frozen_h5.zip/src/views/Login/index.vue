<template>
  <div id="login">
    <div id="back">
      <!-- <i class="iconfont icon-back" @click="$router.back()"></i> -->
    </div>
    <div class="inner-box">
      <div class="inner-logo">
        <div class="inner-bg">
          <img :src="require('assets/login-logo.png')" alt />
        </div>
      </div>
      <div class="inner-title">
          <img :src="require('assets/newlogo.png')" alt="">
        <!-- <p>图片吧</p> -->
        <!-- <p>冻品交易港</p>
        <p>Frozen Product Exchange</p>-->
      </div>
      <div class="inner-form">
        <div id="username-box">
          <input id="username" type="text" placeholder="请输入账户名称" v-model="username" />
          <i class="iconfont icon-yonghu"></i>
        </div>
        <div id="pwd-box">
          <input id="pwd" :type="showPwd===true?'password':'text'" placeholder="请输入密码" v-model="pwd" />
          <i class="iconfont icon-mima"></i>
          <i :class="showPwd===true?'iconfont icon-guanbi-yanjing':'iconfont icon-yanjing'" @click="showPwd=!showPwd" ></i>
        </div>
        <div id="misspwd-box" class="clearfix">
          <p class="misspwd">忘记密码？</p>
        </div>
        <div id="submit">
          <button @click="handleToLogin">登录</button>
        </div>
        <div id="tips">
          <p @click="$router.push('/')">暂不注册，先逛逛</p>
        </div>
        <div id="register" class="clearfix">
          <p>
            还没有注册账号，去
            <span @click="$router.push('./register')">注册</span>
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { login } from "@/api/Login";
import { mapActions } from 'vuex'
import * as types from '@/store/actions-type'
export default {
  data() {
    return {
      showPwd: true,
      username: "",
      pwd: ""
    };
  },
  methods: {
    ...mapActions([types.LOGIN]),
    handleToLogin() {
        // try {
            this[types.LOGIN]({username:'',password:''})
            this.$router.push('/')
        // } catch (e) {
        //     debugger
        // }
        // login({
        //     username: this.username,
        //     password: this.pwd
        // }).then(res => {
        //     if (res.code === 0) {
        //         // this.$toast('00000')
        //     }
        // });
    }
  }
};
</script>

<style lang="scss" scoped>
input::-webkit-input-placeholder {
  color: #fff;
}
#login {
  font-size: 24px;
  width: 100%;
  height: 100%;
  background: url("../../assets/bg.png") no-repeat;
  background-size: 100% 100%;
  padding: 290px 70px 0;
  #back {
    position: fixed;
    left: 33px;
    top: 40px;
    .icon-back:before {
      font-size: 40px;
      color: #fff;
    }
  }
  .inner-box {
    position: relative;
    height: 848px;
    width: 610px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 16px;
    padding: 238px 22px 20px;
    .inner-logo {
      position: absolute;
      top: -100px;
      left: 218px;
      width: 174px;
      height: 174px;
      background: rgba(242, 241, 241, 0.4);
      border-radius: 50%;
      padding: 11px;
      .inner-bg {
        background: url("../../assets/circle.png") no-repeat 100%;
        width: 152px;
          height: 152px;
          border-radius: 50%;
          padding: 16px;
        img {
          width: 120px;
          height: 120px;
        }
      }
    }
    .inner-title {
      position: absolute;
      top: 85px;
      left: 215px;
      img {
          width: 180px;
          height: 70px;
      }
      p {
        text-align: center;
      }
    }
    .inner-form {
      input {
        width: 564px;
        height: 88px;
        background: rgba(89, 157, 226, 1);
        border-radius: 44px;
        color: #fff;
        padding: 0 84px 0;
      }
      #username-box {
        position: relative;
        #username {
          margin-bottom: 24px;
        }
        .icon-yonghu:before {
          position: absolute;
          top: 30px;
          left: 20px;
          font-size: 32px;
          color: #fff;
        }
      }
      #pwd-box {
        position: relative;
        #pwd {
          margin-bottom: 18px;
        }
        .icon-mima:before {
          position: absolute;
          top: 30px;
          left: 34px;
          font-size: 26px;
          color: #fff;
        }
        .icon-guanbi-yanjing:before,
        .icon-yanjing:before {
          position: absolute;
          top: 30px;
          right: 34px;
          font-size: 26px;
          color: #fff;
        }
      }
      #misspwd-box {
        margin-bottom: 71px;
        .misspwd {
          float: right;
          padding-right: 20px;
          color: #fff;
        }
      }
      #submit {
        padding: 0 40px;
        margin-bottom: 34px;
        button {
          width: 480px;
          height: 88px;
          padding: 0 40px;
          background: linear-gradient(
            -13deg,
            rgba(3, 90, 190, 1),
            rgba(33, 142, 237, 1)
          );
          border-radius: 44px;
          color: #fff;
          font-size: 40px;
        }
      }
      #tips {
        padding: 0 100px;
        margin-bottom: 75px;
        p {
          text-align: center;
          color: #fff;
        }
      }
      #register {
        p {
          float: right;
          padding-right: 35px;
          color: #fff;
          span {
            font-size: 32px;
            color: #ea5520;
          }
        }
      }
    }
  }
}
</style>