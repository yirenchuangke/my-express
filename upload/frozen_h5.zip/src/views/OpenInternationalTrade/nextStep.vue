<template>
    <div class="openinternationaltradenext">
        <CCII-Header>国际贸易开通服务</CCII-Header>
        <div class="content">
            <div class="title fs_28 c_666">完善入驻信息</div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    },
    mounted() {

    },
    methods: {

    }
}
</script>

<style lang="scss" scoped>
.openinternationaltradenext {
    height: 100%;
    width: 100%;
    background-color: #F3F3F3;
    .content {
        margin: 15px;
        .title {
            height:80px;
            line-height: 80px;
            border-radius:8px 8px 0px 0px;
            border-bottom: 1px solid #F3F3F3;
            background-color: #fff;
            padding: 0 20px;
        }
    }
}
</style>