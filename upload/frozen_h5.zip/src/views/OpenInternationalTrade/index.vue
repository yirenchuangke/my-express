<template>
    <div class="openinternationaltrade">
        <CCII-Header>国际贸易开通服务</CCII-Header>
        <div class="content">
            <div class="title fs_28 c_666">信息完善页面</div>
            <div class="list">
                <div class="item">
                    <span class="require">开户名称</span>
                    <input type="text" placeholder="请输入企业在银行的开户名称">
                </div>
                <div class="item">
                    <span class="require">开户银行</span>
                    <input type="text" placeholder="请输入公司对公的银行账户行">
                </div>
                <div class="item">
                    <span class="require">开户账号</span>
                    <input type="text" placeholder="请输入公司的对公账户">
                </div>
                <div class="item">
                    <span class="require">开户地址</span>
                    <input type="text" placeholder="请输入公司注册地址">
                </div>
                <div class="item">
                    <span class="require">联系电话</span>
                    <input type="text" placeholder="请输入公司联系电话">
                </div>
                <div class="item">
                    <span class="require">营业执照（税号）</span>
                    <input type="text">
                </div>
                <div class="item">
                    <span>企业logo</span>
                    <div class="upload">
                        <input type="text" readonly>
                        <div class="abs">上传</div>
                    </div>
                </div>
                <div class="next fs_32" @click="$router.push('/openInternationalTrade/nextStep')">下一步</div>
            </div>
        </div>
    </div>
</template>

<script>
import Header from 'components/Header'
export default {
    components: {
        'CCII-Header': Header
    },
    data() {
        return {

        }
    },
    methods: {

    }
}
</script>

<style lang="scss" scoped>
.openinternationaltrade {
    height: 100%;
    width: 100%;
    background-color: #F3F3F3;
    .content {
        margin: 15px;
        .title {
            height:80px;
            line-height: 80px;
            border-radius:8px 8px 0px 0px;
            border-bottom: 1px solid #F3F3F3;
            background-color: #fff;
            padding: 0 20px;
        }
        .list {
            height: 952px;
            padding: 30px;
            background-color: #fff;
            border-radius: 0px 0px 8px 8px;
            .item {
                display: flex;
                justify-content: flex-start;
                align-items: center;
                height: 85px;
                span {
                    margin-right: 20px;
                }
                span.require::before {
                    content: '*';
                    color: #E95520;
                }
                input {
                    flex: 1;
                    height: 64px;
                    border: 1px solid #EDEDED;
                    padding: 0 20px;
                }
                div.upload {
                    position: relative;
                    flex: 1;
                    input {
                        width: 100%;
                        border-radius:0px 32px 32px 0px;
                    }
                    .abs {
                        position: absolute;
                        top: 0;
                        right: 0;
                        width:180px;
                        height:64px;
                        line-height: 64px;
                        background-color: #83C1F1;
                        border-radius:0px 32px 32px 0px;
                        color: #fff;
                        text-align: center;
                    }
                }
            }
            .next {
                width:500px;
                height:88px;
                line-height: 88px;
                background-color: #599DE1;
                border:1px solid #00428D;
                border-radius:42px;
                color: #fff;
                text-align: center;
                margin: 100px auto 0;
            }
        }
    }
}
</style>