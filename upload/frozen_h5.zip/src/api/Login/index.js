import axios from '@/utils/ajaxRequest.js'

// export const doLogin = (data) => {
//     return axios.post({
//         url: '/company/center/doLogin',
//         data: data
//         // headers: {
//         //     'content-type': 'application/x-www-form-urlencoded'
//         // },
//     })
// }

// export const doLogin = (a, b) => {
//     return axios.get({
//         url: `/company/center/doLogin?userName=${a}&password=${b}`,
//     })
// }

export const login = (data) => {
    return axios.post({
        url: 'login',
        data,
    })
}

