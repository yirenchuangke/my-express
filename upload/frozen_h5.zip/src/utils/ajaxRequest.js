import axios from 'axios'
import qs from 'qs'
import { Toast } from 'vant'
import store from '@/store'
import * as types from '@/store/actions-type'

class AjaxRequest {
    constructor() {
        // this.baseURL = process.env.VUE_APP_BASE_API
        this.baseURL = 'http://localhost:8000/'
        this.timeout = 10000
        this.queue = {} // 请求队列
    }

    setInterceptor(instance, url) {
        instance.interceptors.request.use((config) => {
            // 每次请求的时候 都拿到一个取消请求的方法
            let Cancel = axios.CancelToken; // 产生一个请求令牌
            config.cancelToken = new Cancel(function (c) {
                store.commit(types.PUSH_TOKEN, c); // 存储请求
            });
            // 只要页面变化 就要去依次调用cancel方法 路由的钩子 beforeEach

            if (Object.keys(this.queue).length === 0) {
                // 开启toast
                Toast.loading({
                    duration: 0, // 持续展示 toast
                    forbidClick: true,
                    message: 'loading',
                });
            }
            this.queue[url] = url
            return config
        }, err => {
            return Promise.reject(err)
        });
        instance.interceptors.response.use((res) => {
            delete this.queue[url];
            if (Object.keys(this.queue).length === 0) {
                // 关闭toast
                Toast.clear()
            }
            if (res.data.code === 0) {
                return res.data.data
            } else {
                Toast(res.data.msg)
                return Promise.reject(res.data)
            }
        }, err => {
            // Toast('出错啦')
            delete this.queue[url]
            if (Object.keys(this.queue).length === 0) {
                // 关闭toast
                Toast.clear()
            }
            return Promise.reject(err)
        })
    }
    // request(options) {
    //     let instance = axios.create();
    //     let config = {
    //         ...options,
    //         baseURL: this.baseURL,
    //         timeout: this.timeout
    //     }
    //     this.setInterceptor(instance, options.url); // 给这个实例增加拦截功能
    //     return instance(config); // 返回的是一个promise
    // }
    get(options) {
        options.method = 'GET'
        let instance = axios.create();
        let config = {
            ...options,
            baseURL: this.baseURL,
            timeout: this.timeout
        }
        this.setInterceptor(instance, options.url)
        return instance(config)
    }

    post(options) {
        options.method = 'POST'
        options.data = qs.stringify(options.data)
        let instance = axios.create()
        let config = {
            ...options,
            baseURL: this.baseURL,
            timeout: this.timeout
        }
        this.setInterceptor(instance, options.url)
        return instance(config)
    }
    
    post_json(options) {
        options.method = 'POST'
        let instance = axios.create()
        let config = {
            ...options,
            baseURL: this.baseURL,
            timeout: this.timeout
        }
        this.setInterceptor(instance, options.url)
        return instance(config)
    }
}

export default new AjaxRequest
