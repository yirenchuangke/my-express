import loading from 'components/Loading/index.vue'
const loadable = (asyncFunction) => {
    const component = () => ({
        component: asyncFunction(),
        loading
    })
    return {
        render(h) {
            return h(component)
        }
    }
}
export default loadable