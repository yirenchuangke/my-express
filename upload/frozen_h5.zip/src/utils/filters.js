export default {
    /**
     * 给金额添加货币符号
     * @param {金额} value 
     * @param {货币符号} currency 
     */
    addCurrency(value, currency) {
        return currency + value
    }
}
