import Vue from 'vue'
import VueRouter from 'vue-router'
// import loadable from '@/utils/loadable.js'
import hooks from './hook'
import Home from '@/views/Home/index.vue'
import Login from '@/views/Login/index.vue'
import Register from '@/views/Register/index.vue'

Vue.use(VueRouter)

const routes = [
    // 首页
    {
        path: '/',
        name: 'Home',
        component: Home,
        meta: {
            idx: 0, // 转场动画标记值
            hasFooter: true, // 有无footer
            keepAlive: true // 是否需要缓存
        }
    },
    // 登录
    {
        path: '/login',
        name: 'Login',
        component: Login
    },
    // 注册
    {
        path: '/register',
        name: 'Register',
        component: Register
    },
    // 商城
    {
        path: '/shop',
        name: 'Shop',
        component: () => import('@/views/Shop/index.vue'),
        meta: {
            idx: 1,
            hasFooter: true,
            keepAlive: true
        }
    },
    // 圈子
    {
        path: '/circle',
        name: 'Circle',
        component: () => import('@/views/Circle/index.vue'),
        meta: {
            idx: 2,
            hasFooter: true,
            keepAlive: true
        }
    },
    // 发现
    {
        path: '/find',
        name: 'Find',
        component: () => import('@/views/Find/index.vue'),
        meta: {
            idx: 3,
            hasFooter: true,
            keepAlive: true
        }
    },
    // 我的
    {
        path: '/profile',
        name: 'Profile',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '@/views/Profile/index.vue'),
        meta: {
            idx: 4,
            hasFooter: true,
            keepAlive: true
        },
    },
    // ---------------------------------------首页 start↓----------------------------------------
    // 首页->数据统计
    {
        path: '/dataStatistics',
        name: 'DataStatistics',
        component: () => import('@/views/DataStatistics/index.vue'),
        meta: {
            needLogin: true // 是否需要登录后才能访问
        }
    },
    // 首页->销售订单(商城)
    {
        path: '/salesOrder',
        name: 'SalesOrder',
        component: () => import('@/views/SalesOrder/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 首页->采购订单(商城)
    {
        path: '/purchaseOrder/domesticOrders',
        name: 'DomesticOrders',
        component: () => import('@/views/PurchaseOrder/domesticOrders.vue'),
        meta: {
            needLogin: true
        }
    },
    // 首页->采购订单(国际贸易)
    {
        path: '/purchaseOrder/internationalOrders',
        name: 'InternationalOrders',
        component: () => import('@/views/PurchaseOrder/internationalOrders.vue'),
        meta: {
            needLogin: true
        }
    },
    // 首页->库存查询(商城)
    {
        path: '/inventoryQuery/domestic',
        name: 'DomesticInventoryQuery',
        component: () => import('@/views/InventoryQuery/domestic.vue'),
        meta: {
            needLogin: true
        }
    },
    // 首页->库存查询(国际贸易)
    {
        path: '/inventoryQuery/international',
        name: 'InternationalInventoryQuery',
        component: () => import('@/views/InventoryQuery/international.vue'),
        meta: {
            needLogin: true
        }
    },
    // ---------------------------------------首页 end↑----------------------------------------
    // ---------------------------------------商城 start↓----------------------------------------
    // 商城->海外厂商/国内商城
    {
        path: '/shopList',
        name: 'ShopList',
        component: () => import('@/views/ShopList/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 商城->国内商城->进入某个店铺页面
    {
        path: '/domesticStoresList',
        name: 'DomesticStoresList',
        component: () => import('@/views/DomesticStoresList/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 商城->海外厂商->进入某个店铺页面
    {
        path: '/internationalStoresList',
        name: 'InternationalStoresList',
        component: () => import('@/views/InternationalStoresList/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 商城->国内商品详情
    {
        path: '/detailsOfDomesticGoods',
        name: 'DetailsOfDomesticGoods',
        component: () => import('@/views/DetailsOfDomesticGoods/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 商城->国内商品详情->问答->提问
    {
        path: '/detailsOfDomesticGoods/askAQuestion',
        name: 'AskAQuestion',
        component: () => import('@/views/DetailsOfDomesticGoods/askAQuestion.vue'),
        meta: {
            needLogin: true
        }
    },
    // 商城->国内商品详情->采购清单
    {
        path: '/purchaseList',
        name: 'PurchaseList',
        component: () => import('@/views/PurchaseList/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // ---------------------------------------商城 end↑----------------------------------------
    // ---------------------------------------圈子 start↓----------------------------------------
    // 圈子->文章详情
    {
        path: '/circle/detail',
        name: 'CircleDetail',
        component: () => import('@/views/Circle/detail.vue'),
        meta: {
            needLogin: true
        }
    },
    // ---------------------------------------圈子 end↑----------------------------------------
    // ---------------------------------------发现 start↓----------------------------------------
    // 发现->我要用车
    {
        path: '/useCar',
        name: 'UseCar',
        component: () => import('@/views/UseCar/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->冷库预约
    {
        path: '/coldStorage',
        name: 'ColdStorage',
        component: () => import('@/views/ColdStorage/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->冷库预约->详情
    {
        path: '/coldStorage/detail',
        name: 'ColdStorageDetail',
        component: () => import('@/views/ColdStorage/detail.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->供求大厅
    {
        path: '/supplyAndDemandHall',
        name: 'SupplyAndDemandHall',
        component: () => import('@/views/SupplyAndDemandHall/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->国际贸易服务开通
    {
        path: '/openInternationalTrade',
        name: 'OpenInternationalTrade',
        component: () => import('@/views/OpenInternationalTrade/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->国际贸易服务开通->下一步
    {
        path: '/openInternationalTrade/nextStep',
        name: 'OpenInternationalTradeNextStep',
        component: () => import('@/views/OpenInternationalTrade/nextStep.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->国内商城店铺开通
    {
        path: '/openShop',
        name: 'OpenShop',
        component: () => import('@/views/OpenShop/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->企业动态
    {
        path: '/enterpriseDynamics',
        name: 'EnterpriseDynamics',
        component: () => import('@/views/EnterpriseDynamics/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 发现->海外询盘
    {
        path: '/inquiry',
        name: 'Inquiry',
        component: () => import('@/views/Inquiry/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // ---------------------------------------发现 end↑----------------------------------------
    // ---------------------------------------我的 start↓----------------------------------------
    // 我的->企业名片
    {
        path: '/businessCard',
        name: 'BusinessCard',
        component: () => import('@/views/BusinessCard/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->编辑资料
    {
        path: '/information',
        name: 'Information',
        component: () => import('@/views/Information/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->国际贸易订单
    {
        path: '/internationalTradeOrder',
        name: 'InternationalTradeOrder',
        component: () => import('@/views/InternationalTradeOrder/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->国际贸易订单->详情
    {
        path: '/internationalTradeOrder/detail',
        name: 'InternationalTradeOrderDetail',
        component: () => import('@/views/InternationalTradeOrder/detail.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->商城订单
    {
        path: '/mallOrder',
        name: 'MallOrder',
        component: () => import('@/views/MallOrder/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->商城订单->详情
    {
        path: '/mallOrder/detail',
        name: 'MallOrderDetail',
        component: () => import('@/views/MallOrder/Detail/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->商城订单->详情->选择地址
    {
        path: '/mallOrder/detail/receivingAddress',
        name: 'ReceivingAddress',
        component: () => import('@/views/MallOrder/Detail/ReceivingAddress/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->商城订单->详情->选择地址->新增修改
    {
        path: '/mallOrder/detail/receivingAddress/add',
        name: 'ReceivingAddressAdd',
        component: () => import('@/views/MallOrder/Detail/ReceivingAddress/add.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->报价单
    {
        path: '/quotation',
        name: 'Quotation',
        component: () => import('@/views/Quotation/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->报价单->详情
    {
        path: '/quotation/detail',
        name: 'QuotationDetail',
        component: () => import('@/views/Quotation/detail.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->物流订单
    {
        path: '/logisticsOrder',
        name: 'LogisticsOrder',
        component: () => import('@/views/LogisticsOrder/index.vue'),
        meta: {
            needLogin: true
        }
    },
    // 我的->物流订单->详情
    {
        path: '/logisticsOrder/detail',
        name: 'LogisticsOrderDetail',
        component: () => import('@/views/LogisticsOrder/detail.vue'),
        meta: {
            needLogin: true
        }
    },
    // ---------------------------------------我的 end↑----------------------------------------
    // 页面飞走了
    {
        path: '*',
        component: {
            render(h) {
                return <h1> 页面飞走了 </h1>
            }
        }
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

Object.values(hooks).forEach(hook => {
    // 全局前置守卫
    router.beforeEach(hook)
})

export default router
