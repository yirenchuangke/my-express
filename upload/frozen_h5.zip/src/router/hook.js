import store from '@/store'
import * as types from '@/store/actions-type'

export default {
    cancelToken: (to, from, next) => {
        store.commit(types.CLEAR_TOKEN)
        next()
    },
    permission: (to, from, next) => {
        let hasPermission = store.state.hasPermission // 有没有权限
        let needLogin = to.matched.some(item => item.meta.needLogin) // 该页面是否需要登录才能访问
        if (!hasPermission) {
            if (needLogin) {
                next('/login')
            } else {
                next()
            }
        } else {
            if (to.path === '/login' || to.path === '/register') {
                next('/')
            } else {
                next()
            }
        }
    },
}