import Vue from 'vue'
import App from './App.vue'
import router from './router'
import Router from 'vue-router'
import store from './store'
import FastClick from 'fastclick'
import echarts from "echarts"
import filters from '@/utils/filters'

import 'amfe-flexible/index.js'
import './styles/index.scss'
import 'assets/iconfont/iconfont.css'

for (let key in filters) {
    Vue.filter(key, filters[key]);
}

import {
    Button,
    Tabbar,
    TabbarItem,
    Swipe,
    SwipeItem,
    Checkbox,
    CheckboxGroup,
    Uploader,
    Divider,
    NoticeBar,
    Tab,
    Tabs,
    Cell,
    CellGroup,
    Icon,
    Image as VanImage,
    Col,
    Row,
    Popup,
    Calendar,
    DatetimePicker,
    Field,
    Form,
    NumberKeyboard,
    PasswordInput,
    Picker,
    RadioGroup,
    Radio,
    Rate,
    Search,
    Slider,
    Stepper,
    Switch,
    List,
    ShareSheet,
    Toast,
    AddressList,
    Area,
    Sticky,
    DropdownMenu,
    DropdownItem,
    TreeSelect,
    Step,
    Steps,
    ActionSheet,
    AddressEdit,
    Card,
    ContactCard,
    ContactList,
    ContactEdit,
    CouponCell,
    CouponList,
    GoodsAction,
    GoodsActionIcon,
    GoodsActionButton,
    SubmitBar,
    Sku,
    Dialog,
    Loading,
    Notify,
    Overlay,
    PullRefresh,
    SwipeCell,
    Circle,
    Collapse,
    CollapseItem,
    CountDown,
    Empty,
    ImagePreview,
    Lazyload,
    Progress,
    Skeleton,
    Tag,
    Grid,
    GridItem,
    IndexBar,
    IndexAnchor,
    NavBar,
    Pagination,
    Sidebar,
    SidebarItem,

} from 'vant'

Vue.use(Button)
Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(Swipe)
Vue.use(SwipeItem)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
Vue.use(Uploader)
Vue.use(Divider)
Vue.use(NoticeBar)
Vue.use(Tab)
Vue.use(Tabs)
Vue.use(Cell)
Vue.use(CellGroup)
Vue.use(Icon)
Vue.use(VanImage)
Vue.use(Col)
Vue.use(Row)
Vue.use(Popup)
Vue.use(Calendar)
Vue.use(DatetimePicker)
Vue.use(Field)
Vue.use(Form)
Vue.use(NumberKeyboard)
Vue.use(PasswordInput)
Vue.use(Picker)
Vue.use(RadioGroup)
Vue.use(Radio)
Vue.use(Rate)
Vue.use(Search)
Vue.use(Slider)
Vue.use(Stepper)
Vue.use(Switch)
Vue.use(List)
Vue.use(ShareSheet)
Vue.use(Toast)
Vue.use(AddressList)
Vue.use(Area)
Vue.use(Sticky)
Vue.use(DropdownMenu)
Vue.use(DropdownItem)
Vue.use(TreeSelect)
Vue.use(Step)
Vue.use(Steps)

Vue.prototype.$echarts = echarts

FastClick.attach(document.body)

Vue.config.productionTip = false

const VueRouterPush = Router.prototype.push
Router.prototype.push = function push(to) {
    return VueRouterPush.call(this, to).catch(err => err)
}

const VueRouterReplace = Router.prototype.replace
Router.prototype.replace = function replace(to) {
    return VueRouterReplace.call(this, to).catch(err => err)
}

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')
