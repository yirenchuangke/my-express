// 存储请求token
export const PUSH_TOKEN = 'PUSH_TOKEN'
// 清除请求token
export const CLEAR_TOKEN = 'CLEAR_TOKEN'

// 登录
export const LOGIN = 'LOGIN'
// 用户信息
export const SET_UESRINFO = 'SET_UESRINFO'