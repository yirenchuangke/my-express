import Vue from 'vue'
import Vuex from 'vuex'
import createPersistedState from 'vuex-persistedstate'
import { Toast } from 'vant'
import * as types from './actions-type'
import { login } from '@/api/Login'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        ajaxToken: [], // 所有请求
        userInfo: {}, // 用户信息
        hasPermission: false, // 有无权限，登录后为true
    },
    mutations: {
        [types.PUSH_TOKEN](state, cancel) {
            state.ajaxToken = [...state.ajaxToken, cancel]
        },
        [types.CLEAR_TOKEN](state) {
            state.ajaxToken.forEach(cancel => cancel())
            state.ajaxToken = []
        },
        [types.SET_UESRINFO](state, payload) {
            state.userInfo = payload
            state.hasPermission = true
        }
    },
    actions: {
        async [types.LOGIN]({ commit }, user) {
            try {
                let res = await login(user)
                commit(types.SET_UESRINFO, res)
            } catch (e) {
                return Promise.reject(e)
            }
            // await login(user).then(res => {
            //     if (res.code === 0) {
            //         commit(types.SET_UESRINFO, res.data)
            //     } else {
            //         Toast(res.msg)
            //     }
            // })
        }
    },
    modules: {

    },
    plugins: [
        createPersistedState({
            storage: window.sessionStorage,
            reducer(val) {
                return {
                    // 只储存state中的userInfo和hasPermission
                    userInfo: val.userInfo,
                    hasPermission: val.hasPermission
                }
            }
        })
    ],
})
