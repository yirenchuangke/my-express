<template>
  <div class="header">
      <!-- 原为圈子页面使用  暂时弃用 -->
    <div class="header-tab" ref="headertab">
      <ul ref="tabitem">
        <li
          v-for="(item, index) in listArray"
          :key="index"
          :class="index == current ? 'active-li' : ''"
          @click="getTab(index, $event)"
        >
          <span>{{item.name}}</span>
          <!-- 暂时写死 -->
          <img v-if="index == 1" src="../../assets/dalaoshuo.png" />
          <img v-if="index == 2" src="../../assets/qiyeshuo.png" />
        </li>
      </ul>
    </div>
  </div>
</template>
 
<script>
export default {
  name: "Tabs",
  props: {
    listArray: {
      type: Array,
      default: () => []
    },
    current: {
      type: Number,
      default: 1
    }
  },
  data() {
    return {};
  },
  methods: {
    getTab(index, e) {
      this.$emit("change", index, e);
    }
  }
};
</script>
<style lang="scss" scoped>
.header {
  width: 100%;
  height: 80px;
  background-color: #fff;
  display: flex;
}
.header-tab {
  width: 100%;
  height: 100%;
  display: flex;
  flex-wrap: nowrap;
  overflow: scroll;
}
.header-tab::-webkit-scrollbar {
  display: none;
}
ul {
  display: inline-block;
  white-space: nowrap;
}
li {
  display: inline-block;
  line-height: 80px;
  padding: 0px 10px;
  font-size: 28px;
  color: #666666;
}
img {
  width: 105px;
  height: 45px;
  vertical-align: middle;
}
.active-li {
  font-size: 28px;
  position: relative;
  color: #00428e;
}
.active-li:after {
  position: absolute;
  content: "";
  //   width: 50%;
  height: 2px;
  bottom: 0;
  left: 15px;
  right: 15px;
  background-color: #00428e;
}
</style>