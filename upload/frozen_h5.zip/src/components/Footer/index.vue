<template>
  <van-tabbar :value="active" active-color="#00428E" inactive-color="#666666" :border="false">
    <van-tabbar-item v-for="(item, index) in tabs" :key="item.value" replace :to="item.value">
      <span :class="active == index ? 'active-span' : ''">{{item.label}}</span>
      <template #icon="props">
        <img :src="props.active ? item.icon1 : item.icon" />
      </template>
    </van-tabbar-item>
  </van-tabbar>
</template>

<script>
export default {
  name: "Footer",
  props: {
    active: {
      type: Number,
      default: 0
    },
    tabs: {
      type: Array,
      default: () => []
    }
  }
};
</script>

<style lang="scss" scoped>
.van-tabbar--fixed {
  background: rgba(255, 255, 255, 1);
  height: 113.6px;
  box-shadow: -3px -1px 5px 0px #eff1f4;
  img {
    width: 37px;
    height: 37px;
  }
}
.active-span {
  font-weight: 600;
}
</style>