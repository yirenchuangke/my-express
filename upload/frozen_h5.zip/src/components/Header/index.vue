<template>
    <div>
        <div class="CCII-header">
            <i v-if="showBack" class="iconfont icon-zuojiantou" @click="back()"></i>
            <slot></slot>
        </div>
        <div class="empty"></div>
    </div>
</template>

<script>
export default {
    name: 'Header',
    props: {
        showBack: {
            type: Boolean,
            default: true
        }
    },
    data() {
        return {

        }
    },
    methods: {
        back() {
            this.$router.back()
        }
    }
}
</script>

<style lang="scss" scoped>
// .CCII-header {
//     position: absolute;
//     width: 100%;
//     text-align: center;
//     height: 60px;
//     background: #2a2a2a;
//     color: #fff;
//     line-height: 60px;
//     .iconfont-fanhui {
//         position: absolute;
//         left: 15px;
//     }
// }
.empty{
    height: 88px;
}

.CCII-header {
    position: fixed;
    z-index: 9999;
    width: 100%;
    height: 88px;
    line-height: 88px;
    padding: 0 30px;
    text-align: center;
    color: #333333;
    font-size: 36px;
    background-color: #fff;
    border-bottom: 1px solid #F2F2F2;
    .icon-zuojiantou:before {
        position: absolute;
        left: 20px;
        font-size: 40px;
        font-weight: 600;
    }
}
</style>