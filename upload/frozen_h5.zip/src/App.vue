<template>
  <div id="app">
    <transition :name="move">
        <keepAlive>
            <router-view v-if="$route.meta.keepAlive"></router-view>
        </keepAlive>
    </transition>
    <transition :name="move">
      <router-view v-if="!$route.meta.keepAlive"></router-view>
    </transition>
    <CCII-Footer v-if="$route.meta.hasFooter" :active="active" :tabs="tabs" />
  </div>
</template>

<script>
import Footer from "components/Footer";
export default {
  components: {
    "CCII-Footer": Footer
  },
  data() {
    return {
      move: '',
      active: 0,
      tabs: [
        {
          label: "首页",
          value: "/",
          icon: require("assets/shouye.png"),
          icon1: require("assets/shouye-pre.png")
        },
        {
          label: "商城",
          value: "/shop",
          icon: require("assets/shangcheng.png"),
          icon1: require("assets/shangcheng-pre.png")
        },
        {
          label: "圈子",
          value: "/circle",
          icon: require("assets/quanz.png"),
          icon1: require("assets/quanzi-pre.png")
        },
        {
          label: "发现",
          value: "/find",
          icon: require("assets/faxian.png"),
          icon1: require("assets/faxian-pre.png")
        },
        {
          label: "我的",
          value: "/profile",
          icon: require("assets/wode.png"),
          icon1: require("assets/wode-pre.png")
        }
      ]
    };
  },
  watch: {
    $route: {
      handler(to, from) {
        if (to && from) {
            // 当前只做了5个tab的转场动画
          if (to.meta.hasFooter && from.meta.hasFooter) {
            if (to.meta.idx > from.meta.idx) {
              this.move = "slide-left";
            } else {
              this.move = "slide-right";
            }
          } else {
            this.move = '';
          }
        } else {
          this.move = '';
        }
        switch (to.path) {
          case "/":
            return (this.active = 0);
          case "/shop":
            return (this.active = 1);
          case "/circle":
            return (this.active = 2);
          case "/find":
            return (this.active = 3);
          case "/profile":
            return (this.active = 4);
        }
      },
      immediate: true
    }
  },
  methods: {}
};
</script>

<style lang="scss">
// #app
// font-family Avenir, Helvetica, Arial, sans-serif
// -webkit-font-smoothing antialiased
// -moz-osx-font-smoothing grayscale
// text-align center
// color #2c3e50
// margin-top 60px
html,
body,
#app {
  width: 100%;
  height: 100%;
  font-size: 24px;
}

.slide-left-enter-active,
.slide-left-leave-active,
.slide-right-enter-active,
.slide-right-leave-active {
  transition: all 0.3s linear;
}

.slide-left-enter-active,
.slide-right-enter-active {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
}

.slide-right-enter {
  transform: translate(-100%);
}

.slide-right-leave-to {
  transform: translate(100%);
}

.slide-left-enter {
  transform: translate(100%);
}

.slide-left-leave-to {
  transform: translate(-100%);
}
</style>
